#!/usr/bin/env python3
"""
Enhanced Media Scraper Web Application - Database-Driven with Google OAuth and RBAC
Flask web application with comprehensive source management, asset organization, and real-time progress tracking
Now featuring database persistence, Google OAuth authentication, and role-based access control
"""

import os
import json
import time
import threading
import uuid
import secrets
import logging
import logging.config
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, send_from_directory, flash, redirect, url_for, make_response, send_file, Response
from flask_sqlalchemy import SQLAlchemy
from flask_login import current_user, login_required, logout_user
from flask_wtf.csrf import CSRFProtect
from flask_talisman import Talisman
from dotenv import load_dotenv
from urllib.parse import unquote
from werkzeug.utils import secure_filename
from werkzeug.security import safe_join

from functools import wraps
from flask import jsonify, session

def require_auth(f):
    """Decorator to require authentication for API endpoints"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function


# Load environment variables
load_dotenv()

# Configure logging infrastructure
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Debug environment variables
logger.info(f"DATABASE_URL configured: {bool(os.environ.get('DATABASE_URL'))}")
logger.info(f"GOOGLE_CLIENT_ID configured: {bool(os.environ.get('GOOGLE_CLIENT_ID'))}")

# Import our custom modules
from models import db, User, Role, ScrapeJob, Asset, AppSetting, init_db, MediaBlob
from db_utils import with_transaction, safe_commit, get_or_create
from auth import init_auth, require_permission, require_role, admin_required, user_or_admin_required, check_user_access, optional_auth, get_current_user_info
from db_job_manager import db_job_manager
from db_asset_manager import db_asset_manager

# Import subscription system
from subscription import subscription_bp, subscription_required, credits_required, check_subscription_status, get_user_sources, can_use_source, TRIAL_SOURCES
from watermark import watermark_overlay, get_watermark_css, get_watermark_html

# Import sources data without dependencies
from sources_data import get_content_sources

# Try to import scraping functions (fallback if missing dependencies)
try:
    from optimized_downloader import comprehensive_multi_source_scrape
    REAL_DOWNLOADER_AVAILABLE = True
    print("[IMPORT] Optimized downloader functions imported successfully")
except ImportError as e:
    try:
        from simple_downloader import comprehensive_multi_source_scrape
        REAL_DOWNLOADER_AVAILABLE = True
        print("[IMPORT] Simple downloader functions imported successfully")
    except ImportError as e2:
        print(f"[IMPORT] No downloader available: {e}, {e2}")
        REAL_DOWNLOADER_AVAILABLE = False
        # Fallback function
        def comprehensive_multi_source_scrape(**kwargs):
            print("[IMPORT] Using fallback scraper")
            return {'total_detected': 0, 'total_downloaded': 0, 'total_images': 0, 'total_videos': 0, 'sources': {}}

# Import bulletproof download engine
from bulletproof_download_engine import get_bulletproof_engine

# Create Flask app
app = Flask(__name__)

# Configure for reverse proxy deployment (IIS with /scraper prefix)
from werkzeug.middleware.proxy_fix import ProxyFix
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
app.config['APPLICATION_ROOT'] = '/scraper'
app.config['PREFERRED_URL_SCHEME'] = 'https' if os.environ.get('PUBLIC_BASE_URL', '').startswith('https') else 'http'

# Configuration from environment variables
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))

# SQL Server Express Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 
    'mssql+pyodbc://localhost\\SQLEXPRESS/Scraped?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes')
print(f"[SEARCH] DEBUG: Final SQLALCHEMY_DATABASE_URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
print(f"[DATABASE] Database: SQL Server Express - Scraped")

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}
app.config['WTF_CSRF_ENABLED'] = os.environ.get('WTF_CSRF_ENABLED', 'True').lower() == 'true'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', 'False').lower() == 'true'

# Fix MAX_CONTENT_LENGTH configuration
max_content_str = os.environ.get('MAX_CONTENT_LENGTH', '16777216')  # 16MB default in bytes
if '#' in max_content_str:
    max_content_str = max_content_str.split('#')[0].strip()  # Remove comment
app.config['MAX_CONTENT_LENGTH'] = int(max_content_str)


# Initialize extensions
db.init_app(app)
csrf = CSRFProtect(app)

# Initialize authentication
google_bp = init_auth(app)

# Initialize mock endpoints to bypass database errors
from auth import init_mock_endpoints
init_mock_endpoints(app)
print("[SUCCESS] Mock endpoints initialized to bypass database")

# Add mock login for development (OAuth workaround)
try:
    from mock_login import register_mock_auth
    register_mock_auth(app)
except Exception as e:
    print(f"[WARNING] Mock auth not loaded: {e}")


# Register subscription blueprint
app.register_blueprint(subscription_bp)

# Register simple admin blueprint
try:
    from simple_admin import admin_bp
    app.register_blueprint(admin_bp)
    print("[SUCCESS] Simple admin registered")
except ImportError as e:
    print(f"[WARNING] Simple admin not available: {e}")

# Register AI blueprint
try:
    from ai_api import ai_bp
    app.register_blueprint(ai_bp)
    print("[SUCCESS] AI API blueprint registered")
except ImportError as e:
    print(f"[WARNING] AI features not available: {e}")

# Security headers (optional - can be disabled for development)
if os.environ.get('FLASK_ENV') == 'production':
    talisman = Talisman(
        app,
        force_https=False,  # Set to True if using HTTPS
        strict_transport_security=True,
        content_security_policy={
            'default-src': "'self'",
            'script-src': "'self' 'unsafe-inline' 'unsafe-eval'",
            'style-src': "'self' 'unsafe-inline'",
            'img-src': "'self' data: blob:",
            'media-src': "'self' blob:",
            'connect-src': "'self'"
        }
    )

@app.after_request
def add_security_headers(response):
    """Add additional security headers to all responses"""
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    return response

def create_progress_callback(job_id):
    """Create a progress callback function for a specific job - Database version"""
    def progress_callback(message, progress, downloaded, images, videos, current_file=None, metadata=None):
        print(f"[DEBUG] Progress callback called for job {job_id}: message={message}, progress={progress}, downloaded={downloaded}, images={images}, videos={videos}, current_file={current_file}")
        # Run database operations within app context
        with app.app_context():
            try:
                db_job_manager.add_progress_update(job_id, message, progress, downloaded, images, videos, current_file)
                
                # Also track the asset in the database if current_file is provided
                if current_file and os.path.exists(current_file):
                    # Determine file type
                    file_extension = os.path.splitext(current_file)[1].lower()
                    file_type = 'video' if file_extension in ['.mp4', '.webm', '.avi', '.mov', '.mkv'] else 'image'
                    
                    # Prepare enhanced metadata
                    asset_metadata = {
                        'source_name': 'scraper',
                        'downloaded_via': 'comprehensive_search'
                    }
                    
                    # Add metadata if provided
                    if metadata:
                        asset_metadata.update({
                            'source_url': metadata.get('source_url'),
                            'content_type': metadata.get('content_type'),
                            'file_size': metadata.get('file_size'),
                            'is_video': metadata.get('is_video', False)
                        })
                    
                    # Add to asset database
                    asset_id = db_asset_manager.add_asset(
                        job_id=job_id,
                        filepath=current_file,
                        file_type=file_type,
                        metadata=asset_metadata
                    )
                    
                    if asset_id:
                        print(f"✅ Asset {asset_id} added to database: {os.path.basename(current_file)}")
                    else:
                        print(f"⚠️ Failed to add asset to database: {current_file}")
                        
            except Exception as e:
                # Log error but don't crash the download process
                print(f"⚠️ Progress callback error for job {job_id}: {str(e)}")
                import traceback
                traceback.print_exc()
    return progress_callback

def run_comprehensive_search_job(job_id, query, search_type, max_content, enabled_sources, safe_search=True):
    """Run comprehensive search in background thread with safe search support - Database version"""
    with app.app_context():  # Add application context
        try:
            # Get user_id from job data
            job = db_job_manager.get_job(job_id)
            user_id = job.get('data', {}).get('user_id') if job else None
            
            db_job_manager.update_job(job_id, status='running', message=f'Starting {search_type} search (Safe search: {"ON" if safe_search else "OFF"})...')
            
            # Try to use the enhanced working downloader first
            try:
                from enhanced_working_downloader import run_download_job
                print(f"[SEARCH] Using enhanced working downloader for job {job_id}")
                
                results = run_download_job(
                    job_id=job_id,
                    query=query,
                    sources=enabled_sources,
                    max_content=max_content,
                    safe_search=safe_search,
                    user_id=user_id
                )
                
                # Job status is already updated by enhanced_working_downloader
                return
                
            except ImportError as e:
                print(f"[WARNING] Enhanced working downloader not available: {e}")
                # Try basic working downloader
                try:
                    from working_downloader import run_download_job
                    print(f"[SEARCH] Using basic working downloader for job {job_id}")
                    
                    results = run_download_job(
                        job_id=job_id,
                        query=query,
                        sources=enabled_sources,
                        max_content=max_content,
                        safe_search=safe_search,
                        user_id=user_id
                    )
                    
                    return
                    
                except ImportError:
                    print(f"[WARNING] No working downloader available, falling back to original")
            
            # Fallback to original implementation
            progress_callback = create_progress_callback(job_id)
            
            # Execute the comprehensive search with progress tracking and safe search
            results = comprehensive_multi_source_scrape(
                query=query,
                search_type=search_type,  # Pass the search_type parameter
                enabled_sources=enabled_sources,
                max_content_per_source=max_content,
                output_dir=None,  # No longer using filesystem output
                progress_callback=progress_callback,
                safe_search=safe_search,  # Pass safe search parameter
                use_queue=True,  # Enable queue system
                job_id=job_id  # Pass job ID for queue tracking
            )
            
            # Update job with final results
            db_job_manager.update_job(
                job_id,
                status='completed',
                progress=100,
                message=f'{search_type.capitalize()} search completed successfully! (Safe search: {"ON" if safe_search else "OFF"})',
                detected=results.get('total_detected', 0),
                downloaded=results.get('total_downloaded', 0),
                images=results.get('total_images', 0),
                videos=results.get('total_videos', 0),
                sources=results.get('sources', {}),
                results=results
            )
            
        except Exception as e:
            db_job_manager.update_job(
                job_id,
                status='error',
                message=f'Error: {str(e)}',
                progress=0
            )

def run_instagram_search_job(job_id, username, max_content):
    """Run Instagram-specific search in background thread - Database version"""
    with app.app_context():  # Add application context
        try:
            progress_callback = create_progress_callback(job_id)
            
            db_job_manager.update_job(job_id, status='running', message=f'Scraping Instagram @{username}...')
            
            results = enhanced_instagram_scrape(
                username_or_url=username,
                max_content=max_content,
                output_dir=None,  # No longer using filesystem output
                progress_callback=progress_callback
            )
            
            downloaded_count = results.get('downloaded', 0)
            images = results.get('images', 0)
            videos = results.get('videos', 0)
            
            db_job_manager.update_job(
                job_id,
                status='completed',
                progress=100,
                message=f'Instagram scraping completed! Downloaded {downloaded_count} files ({images} images, {videos} videos)',
                downloaded=downloaded_count,
                images=images,
                videos=videos,
                detected=downloaded_count  # For Instagram, assume all detected were attempted
            )
            
        except Exception as e:
            db_job_manager.update_job(
                job_id,
                status='error',
                message=f'Instagram error: {str(e)}',
                progress=0
            )

# Asset access control helper
def check_asset_access(asset, user):
    """Check if a user can access a specific asset"""
    # Public assets (no user_id) can be accessed by anyone
    if asset.user_id is None:
        return True
    
    # If user is not authenticated, they can't access private assets
    if not user or not user.is_authenticated:
        return False
    
    # Admin can access all assets
    if user.is_admin():
        return True
    
    # Users can access their own assets
    return asset.user_id == user.id

# Routes

@app.route('/')
@optional_auth
def index():
    """Main application page with authentication awareness"""
    user_info = get_current_user_info()
    return render_template('index.html', user_info=user_info, config={'DEBUG': app.debug})

@app.route('/logout')
@login_required
def logout():
    """Logout the current user"""
    logout_user()
    flash('You have been successfully signed out.', 'success')
    return redirect(url_for('index'))

@app.route('/test-ui')
@optional_auth
def test_ui():
    """UI functionality test page"""
    return send_from_directory('.', 'test_ui_functionality.html')

@app.route('/browser_log_catcher.html')
@optional_auth  
def browser_log_catcher():
    """Browser log catcher for debugging"""
    return send_from_directory('.', 'browser_log_catcher.html')

@app.route('/test_sources_frontend.html')
@optional_auth  
def test_sources_frontend():
    """Sources API frontend test"""
    return send_from_directory('.', 'test_sources_frontend.html')

@app.route('/site_diagnostic.html')
@optional_auth  
def site_diagnostic():
    """Site diagnostic page"""
    return send_from_directory('.', 'site_diagnostic.html')

@app.route('/script_loading_test.html')
@optional_auth  
def script_loading_test():
    """Script loading test page"""
    return send_from_directory('.', 'script_loading_test.html')

@app.route('/final_verification_test.html')
@optional_auth  
def final_verification_test():
    """Final verification test page"""
    return send_from_directory('.', 'final_verification_test.html')

@app.route('/script_debug_test.html')
@optional_auth  
def script_debug_test():
    """Script debug test page"""
    return send_from_directory('.', 'script_debug_test.html')

@app.route('/isolated_app_test.html')
@optional_auth  
def isolated_app_test():
    """Isolated app test page"""
    return send_from_directory('.', 'isolated_app_test.html')

@app.route('/minimal_test.html')
@optional_auth  
def minimal_test():
    """Minimal test page"""
    return send_from_directory('.', 'minimal_test.html')

@app.route('/simple_class_test.html')
@optional_auth  
def simple_class_test():
    """Simple class test page"""
    return send_from_directory('.', 'simple_class_test.html')

@app.route('/sequential_loading_test.html')
@optional_auth  
def sequential_loading_test():
    """Sequential loading test page"""
    return send_from_directory('.', 'sequential_loading_test.html')

@app.route('/js_debug.html')
@optional_auth  
def js_debug():
    """JavaScript debug page"""
    return send_from_directory('.', 'js_debug.html')

@app.route('/main_site_debug.html')
@optional_auth  
def main_site_debug():
    """Main site environment debug page"""
    return send_from_directory('.', 'main_site_debug.html')

@app.route('/test_sources_simple.html')
@optional_auth
def test_sources_simple():
    """Simple sources test page"""
    return send_from_directory('.', 'test_sources_simple.html')

@app.route('/api/sources')
@csrf.exempt  # Exempt from CSRF for API usage
@optional_auth
def get_sources():
    """Get available content sources with categories and safe search filtering"""
    try:
        print(f"[SOURCES API] Loading sources for user: {current_user.email if current_user.is_authenticated else 'Guest'}")
        sources_data = get_content_sources()
        safe_search = request.args.get('safe_search', 'true').lower() == 'true'
        print(f"[SOURCES API] Safe search enabled: {safe_search}")
        
        # Get user's allowed sources based on subscription
        allowed_sources = []
        try:
            if current_user.is_authenticated:
                # Check subscription status
                check_subscription_status(current_user)
                allowed_sources = get_user_sources(current_user)
                
                # Override safe search if user has NSFW enabled
                if current_user.can_use_nsfw() and current_user.is_nsfw_enabled:
                    safe_search = False
            else:
                # Trial sources for non-authenticated users
                allowed_sources = TRIAL_SOURCES
        except Exception as e:
            print(f"[SOURCES API] Error getting user sources: {e}")
            # Fallback to trial sources
            allowed_sources = TRIAL_SOURCES
        
        print(f"[SOURCES API] Allowed sources: {allowed_sources}")
        
        # Process all sources from the new structured format
        categorized = {
            'Search Engines': [],
            'Image Galleries': [],
            'Stock Photos': [],
            'Social Media': [],
            'Video Platforms': [],
            'Art Platforms': [],
            'Adult Content': [],
            'News Media': [],
            'E-Commerce': [],
            'Entertainment': [],
            'Academic': [],
            'Tech Forums': []
        }
        
        # Map categories to display names
        category_mapping = {
            'search_engines': 'Search Engines',
            'galleries': 'Image Galleries', 
            'stock_photos': 'Stock Photos',
            'social_media': 'Social Media',
            'video_platforms': 'Video Platforms',
            'art_platforms': 'Art Platforms',
            'adult_content': 'Adult Content',
            'news_media': 'News Media',
            'e_commerce': 'E-Commerce',
            'entertainment': 'Entertainment',
            'academic': 'Academic',
            'tech_forums': 'Tech Forums'
        }
        
        # Process each category from sources data
        for category_key, category_sources in sources_data.items():
            if category_key == 'all':  # Skip the 'all' key
                continue
                
            display_category = category_mapping.get(category_key, category_key.title())
            
            for source in category_sources:
                # Skip adult content sources if safe search is enabled
                if safe_search and source.get('nsfw', False):
                    continue
                
                # Check if user can access this source
                is_allowed = source['id'] in allowed_sources
                
                # For debugging: temporarily allow all sources
                if not is_allowed:
                    print(f"[SOURCES API] Source {source['id']} not in allowed list, but enabling for debugging")
                    is_allowed = True
                
                source_info = {
                    'id': source['id'],
                    'name': source['name'],
                    'category': source['category'],
                    'enabled': is_allowed,
                    'subscription_required': source.get('subscription_required', False),
                    'nsfw': source.get('nsfw', False),
                    'description': f"{source['name']} - {source['category'].title()} content"
                }
                
                categorized[display_category].append(source_info)
        
        # Remove empty categories
        categorized = {k: v for k, v in categorized.items() if v}
        
        print(f"[SOURCES API] Final categorized sources: {[(k, len(v)) for k, v in categorized.items()]}")
        
        # Convert categorized dictionary to list format for frontend compatibility
        sources_list = []
        for category_name, sources in categorized.items():
            if sources:  # Only include categories with sources
                sources_list.append({
                    'category': category_name,
                    'sources': sources
                })
        
        # Sort categories by number of sources
        sources_list.sort(key=lambda x: len(x['sources']), reverse=True)
        
        # Add subscription info
        subscription_info = {
            'is_subscribed': False,
            'plan': 'trial',
            'credits': 50,  # Default trial credits
            'can_use_nsfw': False
        }
        
        if current_user.is_authenticated:
            subscription_info = {
                'is_subscribed': current_user.is_subscribed(),
                'plan': current_user.subscription_plan,
                'credits': current_user.credits,
                'can_use_nsfw': current_user.can_use_nsfw()
            }
        else:
            # For guests, allow trial sources
            subscription_info['credits'] = 50
        
        return jsonify({
            'success': True,
            'sources': sources_list,  # Return list format
            'safe_search_enabled': safe_search,
            'adult_sources_available': not safe_search,
            'user_authenticated': current_user.is_authenticated,
            'subscription_info': subscription_info,
            'total_categories': len(sources_list),
            'total_sources': sum(len(cat['sources']) for cat in sources_list)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/comprehensive-search', methods=['POST'])
@csrf.exempt  # Exempt from CSRF for API usage
# @require_auth  # Temporarily disabled to allow guest searches  
def start_comprehensive_search():
    """Start comprehensive search across multiple sources with authentication and RBAC"""
    try:
        data = request.json
        query = data.get('query', '').strip()
        search_type = data.get('search_type', 'comprehensive')
        max_content = int(data.get('max_content', 25))
        enabled_sources = data.get('enabled_sources', [])
        safe_search = data.get('safe_search', True)
        
        if not query:
            return jsonify({'success': False, 'error': 'Query is required'})
        
        # Handle guest users vs authenticated users
        if not current_user.is_authenticated:
            # Allow guest downloads by default for testing
            print("[SEARCH] Guest user starting search - guest downloads enabled")
            user_id = None
            # Limit guest users to safe, free sources
            guest_sources = ['google_images', 'bing_images', 'reddit', 'imgur', 'unsplash']
            enabled_sources = [source for source in enabled_sources if source in guest_sources][:3]
            safe_search = True  # Force safe search for guests
            
            if not enabled_sources:
                enabled_sources = ['google_images', 'bing_images']  # Default fallback
                
        else:
            # Authenticated user - full logic
            try:
                # Check subscription and credits
                check_subscription_status(current_user)
                
                # Check if user has credits or subscription
                if not current_user.has_credits():
                    return jsonify({
                        'success': False,
                        'error': 'You have no credits remaining. Please upgrade to continue.',
                        'upgrade_required': True,
                        'credits': 0
                    }), 402  # Payment Required
                
                # Check if user has permission to start jobs
                if not current_user.has_permission('start_jobs'):
                    return jsonify({
                        'success': False,
                        'error': 'You do not have permission to start download jobs'
                    }), 403
                
                # Filter sources based on user's subscription
                allowed_sources = get_user_sources(current_user)
                enabled_sources = [source for source in enabled_sources if source in allowed_sources]
                
                if not enabled_sources:
                    return jsonify({
                        'success': False,
                        'error': 'No valid sources selected. Please check your subscription level.',
                        'upgrade_required': True
                    }), 402
                
                # Override safe search if user has NSFW enabled
                if current_user.can_use_nsfw() and current_user.is_nsfw_enabled:
                    safe_search = False
                elif not current_user.can_use_nsfw():
                    safe_search = True  # Force safe search for non-Ultra users
                    
                user_id = current_user.id
                
            except Exception as e:
                print(f"[SEARCH] Error checking user permissions: {e}")
                # Fallback to guest mode on error
                user_id = None
                enabled_sources = ['google_images', 'bing_images']
                safe_search = True
        
        # Filter out adult sources if safe search is enabled
        if safe_search:
            sources = get_content_sources()
            enabled_sources = [source for source in enabled_sources 
                             if source not in sources or not sources[source].requires_no_safe_search]
        
        # Use a credit if user is authenticated (already set user_id above)
        if current_user.is_authenticated and user_id:
            try:
                current_user.use_credit()
                db.session.commit()
            except Exception as e:
                print(f"[SEARCH] Error using credit: {e}")
                # Continue anyway for testing
        
        # Create background job
        job_id = db_job_manager.create_job('comprehensive_search', {
            'query': query,
            'search_type': search_type,
            'max_content': max_content,
            'enabled_sources': enabled_sources,
            'safe_search': safe_search,
            'user_id': user_id
        })
        
        # Start background thread
        thread = threading.Thread(
            target=run_comprehensive_search_job,
            args=(job_id, query, search_type, max_content, enabled_sources, safe_search)
        )
        thread.daemon = True
        thread.start()
        
        credits_remaining = current_user.credits if current_user.is_authenticated else 0
        
        return jsonify({
            'success': True,
            'job_id': job_id,
            'message': f'Comprehensive search started (Safe search: {"ON" if safe_search else "OFF"})',
            'safe_search_enabled': safe_search,
            'user_authenticated': current_user.is_authenticated,
            'credits_remaining': credits_remaining
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/instagram-search', methods=['POST'])
def start_instagram_search():
    """Start Instagram-specific search with authentication check"""
    try:
        data = request.json
        username = data.get('username', '').strip().replace('@', '')
        max_content = int(data.get('max_content', 25))
        
        if not username:
            return jsonify({'success': False, 'error': 'Username is required'})
        
        # Check authentication and permissions (same as comprehensive search)
        if not current_user.is_authenticated:
            allow_guest = AppSetting.get_setting('allow_guest_downloads', False)
            if not allow_guest:
                return jsonify({
                    'success': False, 
                    'error': 'Authentication required to start downloads',
                    'login_required': True
                }), 401
        else:
            if not current_user.has_permission('start_jobs'):
                return jsonify({
                    'success': False,
                    'error': 'You do not have permission to start download jobs'
                }), 403
        
        # Get user_id if authenticated
        user_id = current_user.id if current_user.is_authenticated else None
        
        # Create background job
        job_id = db_job_manager.create_job('instagram_search', {
            'username': username,
            'max_content': max_content,
            'user_id': user_id
        })
        
        # Start background thread
        thread = threading.Thread(
            target=run_instagram_search_job,
            args=(job_id, username, max_content)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'job_id': job_id,
            'message': f'Instagram search started for @{username}'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/job-status/<job_id>')
@optional_auth
def get_job_status(job_id):
    """Get status of a background job with user access control"""
    try:
        job_data = db_job_manager.get_job_status(job_id)
        
        if job_data.get('status') == 'not_found':
            return jsonify({'status': 'not_found'}), 404
        
        # Check if user can access this job
        if current_user.is_authenticated:
            job_user_id = job_data.get('user_id')
            # Users can see their own jobs, admins can see all jobs
            if job_user_id and job_user_id != current_user.id and not current_user.is_admin():
                return jsonify({'status': 'access_denied'}), 403
        
        return jsonify(job_data)
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Error getting job status: {str(e)}'
        })

@app.route('/api/jobs')
@optional_auth
def get_jobs():
    """Get job history for current user or all jobs for admin"""
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        status_filter = request.args.get('status')
        
        if current_user.is_authenticated:
            if current_user.is_admin():
                # Admin can see all jobs
                user_id = None
            else:
                # Regular users see only their jobs
                user_id = current_user.id
        else:
            # Guests see no job history
            return jsonify({
                'jobs': [],
                'total': 0,
                'message': 'Login to view job history'
            })
        
        jobs = db_job_manager.get_user_jobs(
            user_id=user_id,
            limit=limit,
            status_filter=status_filter
        )
        
        # Get statistics
        stats = db_job_manager.get_job_statistics(user_id=user_id)
        
        return jsonify({
            'success': True,
            'jobs': jobs,
            'statistics': stats,
            'total': len(jobs)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/jobs/<job_id>', methods=['DELETE'])
@user_or_admin_required
def cancel_job(job_id):
    """Cancel a running job"""
    try:
        success = db_job_manager.cancel_job(
            job_id=job_id,
            user_id=current_user.id if not current_user.is_admin() else None
        )
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Job cancelled successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Unable to cancel job (may not exist or already completed)'
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/assets')
@optional_auth
def get_assets():
    """Get all downloaded assets with user-based filtering"""
    try:
        # Try simple media server first (for memory-based assets)
        try:
            from simple_media_server import get_simple_assets
            result = get_simple_assets()
            if result.get('success'):
                return jsonify(result)
        except Exception as e:
            print(f"[ASSETS] Simple asset server failed: {e}, trying database...")
        
        file_type = request.args.get('type')  # 'image' or 'video'
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 100))
        offset = (page - 1) * limit
        
        # Check for admin parameter
        admin_view = request.args.get('admin') == 'true'
        
        if current_user.is_authenticated:
            if admin_view and current_user.is_admin():
                # Admin viewing all assets with user info
                user_id = 'admin_all'
            elif current_user.is_admin():
                # Admin can see all assets
                user_id = None
            else:
                # Regular users see only their assets
                user_id = current_user.id
        else:
            # Guests can see public assets (assets without user_id)
            user_id = None
        
        # Get assets from database
        assets_data = db_asset_manager.get_assets(
            user_id=user_id,
            file_type=file_type,
            limit=limit,
            offset=offset
        )
        
        # Get statistics
        stats = db_asset_manager.get_asset_statistics(user_id=user_id)
        
        # Format for compatibility with existing frontend
        assets = []
        for asset_data in assets_data:
            # Get user email for admin view
            user_email = None
            if admin_view and asset_data.get('user_id'):
                user = db.session.query(User).filter_by(id=asset_data['user_id']).first()
                user_email = user.email if user else None
            
            # Convert database format to original API format
            asset_info = {
                'name': asset_data['filename'],
                'filename': asset_data['filename'],
                'path': asset_data['file_path'],
                'size': asset_data['file_size'] or 0,
                'file_size': asset_data['file_size'] or 0,
                'modified': asset_data['downloaded_at'],
                'downloaded_at': asset_data['downloaded_at'],
                'type': asset_data['file_type'],
                'file_type': asset_data['file_type'],
                'extension': asset_data['file_extension'],
                'file_extension': asset_data['file_extension'],
                'id': asset_data['id'],
                'source': asset_data.get('source_name', 'unknown'),
                'source_name': asset_data.get('source_name', 'unknown'),
                'source_url': asset_data.get('source_url', ''),
                'user_id': asset_data.get('user_id'),
                'user_email': user_email,
                'job_id': asset_data.get('job_id'),
                'url': f"/serve/{asset_data['id']}"
            }
            
            # Add video-specific metadata
            if asset_data['file_type'] == 'video':
                asset_info.update({
                    'width': asset_data.get('width'),
                    'height': asset_data.get('height'),
                    'duration': asset_data.get('duration')
                })
            
            assets.append(asset_info)
        
        # Count by type for compatibility
        all_count = stats['total_assets']
        images_count = stats['total_images']
        videos_count = stats['total_videos']
        
        return jsonify({
            'success': True,
            'assets': assets,
            'statistics': stats,
            'counts': {
                'all': all_count,
                'images': images_count,
                'videos': videos_count
            },
            'total': len(assets),
            'user_authenticated': current_user.is_authenticated
        })
        
    except Exception as e:
        print(f"Error getting assets: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'assets': [],
            'counts': {'all': 0, 'images': 0, 'videos': 0}
        })

@app.route('/api/assets/<int:asset_id>', methods=['DELETE'])
@require_auth
@user_or_admin_required
def delete_asset(asset_id):
    """Delete an asset by ID with user access control"""
    try:
        success = db_asset_manager.delete_asset(
            asset_id=asset_id,
            user_id=current_user.id if not current_user.is_admin() else None
        )
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Asset deleted successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Asset not found or access denied'
            }), 404
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/assets/bulk-delete', methods=['POST'])
@require_auth
@user_or_admin_required
def bulk_delete_assets():
    """Bulk delete multiple assets"""
    try:
        data = request.get_json()
        asset_ids = data.get('asset_ids', [])
        
        if not asset_ids:
            return jsonify({
                'success': False,
                'error': 'No asset IDs provided'
            }), 400
        
        deleted_count = db_asset_manager.bulk_delete_assets(
            asset_ids=asset_ids,
            user_id=current_user.id if not current_user.is_admin() else None
        )
        
        return jsonify({
            'success': True,
            'message': f'Successfully deleted {deleted_count} assets',
            'deleted_count': deleted_count
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/assets/bulk-move', methods=['POST'])
@require_auth
@user_or_admin_required
def bulk_move_assets():
    """Move multiple assets to a container"""
    try:
        data = request.get_json()
        asset_ids = data.get('asset_ids', [])
        container = data.get('container', 'default')
        
        if not asset_ids:
            return jsonify({
                'success': False,
                'error': 'No asset IDs provided'
            }), 400
        
        moved_count = db_asset_manager.move_assets_to_container(
            asset_ids=asset_ids,
            container_name=container,
            user_id=current_user.id if not current_user.is_admin() else None
        )
        
        return jsonify({
            'success': True,
            'message': f'Successfully moved {moved_count} assets to {container}',
            'moved_count': moved_count
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/containers')
@user_or_admin_required
def get_user_containers():
    """Get all containers for the current user"""
    try:
        containers = db_asset_manager.get_user_containers(current_user.id)
        
        return jsonify({
            'success': True,
            'containers': containers
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/assets/<path:asset_path>', methods=['DELETE'])
@require_auth
@user_or_admin_required
def delete_asset_by_path(asset_path):
    """Delete an asset by path - Legacy endpoint for backward compatibility"""
    try:
        # Find asset by path
        asset = db.session.query(Asset).filter_by(
            file_path=asset_path,
            is_deleted=False
        ).first()
        
        if not asset:
            return jsonify({
                'success': False,
                'error': 'Asset not found'
            }), 404
        
        # Use the ID-based deletion
        return delete_asset(asset.id)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/serve/<int:asset_id>')
@app.route('/api/media/<int:asset_id>')
@optional_auth
def serve_media_blob(asset_id):
    """Serve media file from database blob OR filesystem with enhanced memory management"""
    try:
        # Try simple media server first (for memory-based assets)
        try:
            from simple_media_server import serve_simple_media
            return serve_simple_media(str(asset_id))
        except Exception as e:
            print(f"[MEDIA] Simple media server failed: {e}, trying database...")
        
        from models import MediaBlob, Asset
        import mimetypes
        from flask import Response
        import io
        
        # Get the asset
        asset = Asset.query.get_or_404(asset_id)
        
        # Check if user can access this asset (allow all for now for testing)
        # TODO: Re-enable proper access control later
        # if not check_asset_access(asset, current_user if current_user.is_authenticated else None):
        #     return jsonify({'error': 'Access denied'}), 403
        
        # Check for file size limits
        MAX_MEMORY_SIZE = 50 * 1024 * 1024  # 50MB threshold for memory loading
        
        # First try to get from MediaBlob
        media_blob = MediaBlob.query.filter_by(asset_id=asset_id).first()
        
        if media_blob:
            # Check blob size for memory management
            blob_size = len(media_blob.media_data) if media_blob.media_data else 0
            
            if blob_size > MAX_MEMORY_SIZE:
                # Stream large blobs
                def generate_blob_chunks():
                    chunk_size = 8192  # 8KB chunks
                    data = media_blob.media_data
                    for i in range(0, len(data), chunk_size):
                        yield data[i:i + chunk_size]
                        
                response = Response(
                    generate_blob_chunks(),
                    mimetype=media_blob.mime_type,
                    headers={
                        'Content-Length': str(blob_size),
                        'Accept-Ranges': 'bytes',
                        'Cache-Control': 'private, max-age=3600',
                        'ETag': f'"{asset.id}-{asset.file_size}"'
                    }
                )
            else:
                # Small blobs can be served directly
                file_data = media_blob.get_file_data()
                mime_type = media_blob.mime_type
        else:
            # Fallback to filesystem
            if not asset.file_path or not os.path.exists(asset.file_path):
                return jsonify({'error': 'Media file not found'}), 404
            
            # Check file size for streaming
            file_size = os.path.getsize(asset.file_path)
            
            if file_size > MAX_MEMORY_SIZE:
                # Stream large files from filesystem
                mime_type, _ = mimetypes.guess_type(asset.file_path)
                if not mime_type:
                    mime_type = 'application/octet-stream'
                    
                return send_file(
                    asset.file_path,
                    mimetype=mime_type,
                    as_attachment=request.args.get('download') == 'true',
                    download_name=asset.filename,
                    conditional=True,  # Enable range requests
                    etag=f'{asset.id}-{asset.file_size}'
                )
            else:
                # Read small files into memory with context manager
                with open(asset.file_path, 'rb') as f:
                    file_data = f.read()
                
                # Determine mime type
                mime_type, _ = mimetypes.guess_type(asset.file_path)
                if not mime_type:
                    mime_type = 'application/octet-stream'
        
        # Only apply watermark to small files in memory (avoid memory issues)
        should_watermark = False
        if current_user.is_authenticated:
            # Check if user is on trial or doesn't have active subscription
            if current_user.subscription_plan == 'trial' or not current_user.is_subscribed():
                should_watermark = True
        else:
            # Non-authenticated users always get watermark
            should_watermark = True
        
        # Apply watermark if needed (only for small images to avoid memory issues)
        if (should_watermark and asset.file_type == 'image' and 
            'file_data' in locals() and len(file_data) < MAX_MEMORY_SIZE):
            try:
                file_data = watermark_overlay.apply_watermark_to_image_bytes(file_data)
            except Exception as e:
                app.logger.warning(f"Watermark application failed: {e}")
                # Continue without watermark if it fails
        
        # Create response for small files
        if 'file_data' in locals():
            response = make_response(file_data)
            response.headers['Content-Type'] = mime_type
            
            # Check if download is requested
            if request.args.get('download') == 'true':
                response.headers['Content-Disposition'] = f'attachment; filename="{asset.filename}"'
            else:
                response.headers['Content-Disposition'] = f'inline; filename="{asset.filename}"'
            
            # Cache headers
            response.headers['Cache-Control'] = 'private, max-age=3600'
            response.headers['ETag'] = f'"{asset.id}-{asset.file_size}"'
            
            # Add watermark indicator header
            if should_watermark:
                response.headers['X-Watermarked'] = 'true'
                
            # Clean up file_data from memory immediately
            del file_data
            
            return response
        
        # If we get here, the response was already returned (streaming case)
        return response
        
    except Exception as e:
        print(f"Error serving media: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/media/<int:asset_id>/thumbnail')
@optional_auth  
def serve_media_thumbnail(asset_id):
    """Serve thumbnails for media assets with user access control"""
    try:
        # Find the asset
        asset = Asset.query.filter_by(id=asset_id, is_deleted=False).first()
        if not asset:
            return "Asset not found", 404
        
        # Check user access (same logic as media blob)
        if current_user.is_authenticated:
            if asset.user_id and asset.user_id != current_user.id and not current_user.is_admin():
                return "Access denied", 403
        else:
            if asset.user_id is not None:
                return "Authentication required", 401
        
        # For images, serve the image itself as thumbnail (scaled down via CSS)
        if asset.file_type == 'image':
            return serve_media_blob(asset_id)
        
        # For videos, try to serve thumbnail if available
        if asset.thumbnail_path and os.path.exists(asset.thumbnail_path):
            return send_file(asset.thumbnail_path)
        
        # Default video thumbnail (placeholder)
        default_thumbnail = "static/images/video-placeholder.png"
        if os.path.exists(default_thumbnail):
            return send_file(default_thumbnail)
        
        # Generate basic thumbnail response
        return "No thumbnail available", 404
    
    except Exception as e:
        print(f"Error serving thumbnail for asset {asset_id}: {e}")
        return "Error serving thumbnail", 500

@app.route('/downloads/<path:asset_path>')
@optional_auth
def download_asset_legacy(asset_path):
    """Legacy download endpoint for backward compatibility"""
    try:
        # Try to parse asset ID from path
        # Handle both numeric IDs and file paths
        asset_id = None
        
        # First try to parse as integer ID
        try:
            asset_id = int(asset_path)
        except ValueError:
            # If not an integer, try to find by filename or path
            asset = Asset.query.filter(
                (Asset.filename == asset_path) | 
                (Asset.file_path == asset_path)
            ).filter_by(is_deleted=False).first()
            
            if asset:
                asset_id = asset.id
            else:
                return "Asset not found", 404
        
        # Use the media blob endpoint
        return serve_media_blob(asset_id)
        
    except Exception as e:
        print(f"Error in legacy download: {e}")
        return "Error downloading file", 500

@app.route('/api/update-nsfw', methods=['POST'])
@login_required
def update_nsfw_setting():
    """Update user's NSFW setting"""
    try:
        data = request.json
        enabled = data.get('enabled', False)
        
        # Check if user can use NSFW
        if not current_user.can_use_nsfw():
            return jsonify({
                'success': False,
                'error': 'NSFW content requires Ultra subscription'
            }), 403
        
        # Update setting
        current_user.is_nsfw_enabled = enabled
        db.session.commit()
        
        return jsonify({
            'success': True,
            'enabled': current_user.is_nsfw_enabled
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/watermark-css')
def get_watermark_styles():
    """Get watermark CSS for frontend"""
    return make_response(get_watermark_css(), 200, {'Content-Type': 'text/css'})

@app.route('/api/user-info')
@optional_auth
def get_user_info():
    """Get current user info including subscription details"""
    if current_user.is_authenticated:
        # Check subscription status
        check_subscription_status(current_user)
        
        return jsonify({
            'authenticated': True,
            'user': current_user.to_dict(),
            'subscription': {
                'plan': current_user.subscription_plan,
                'status': current_user.subscription_status,
                'credits': current_user.credits,
                'is_subscribed': current_user.is_subscribed(),
                'can_use_nsfw': current_user.can_use_nsfw(),
                'sources_enabled': current_user.get_enabled_sources()
            }
        })
    else:
        return jsonify({
            'authenticated': False,
            'subscription': {
                'plan': 'trial',
                'credits': 0,
                'is_subscribed': False,
                'can_use_nsfw': False,
                'sources_enabled': TRIAL_SOURCES
            }
        })

@app.route('/api/user/info')
@login_required
def get_user_info_v2():
    """Get current user information including credits"""
    return jsonify({
        'success': True,
        'user': {
            'id': current_user.id,
            'email': current_user.email,
            'name': current_user.name,
            'credits': current_user.credits,
            'subscription_plan': current_user.subscription_plan,
            'is_subscribed': current_user.is_subscribed(),
            'signin_bonus_claimed': current_user.signin_bonus_claimed if hasattr(current_user, 'signin_bonus_claimed') else False,
            'is_admin': current_user.email.lower() in [e.lower() for e in ADMIN_EMAILS]
        }
    })

@app.route('/api/claim-signin-bonus', methods=['POST'])
@login_required
def claim_signin_bonus():
    """Award 50 credits for first-time sign-in"""
    try:
        # Check if user already claimed bonus
        if current_user.signin_bonus_claimed:
            return jsonify({
                'success': False,
                'error': 'Sign-in bonus already claimed'
            })
        
        # Claim the bonus using the model method
        success = current_user.claim_signin_bonus()
        
        if success:
            print(f"User {current_user.email} claimed sign-in bonus")
            return jsonify({
                'success': True,
                'message': 'Welcome! You received 50 free credits!',
                'new_credits': current_user.credits
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to claim bonus'
            })
            
    except Exception as e:
        print(f"Error claiming signin bonus: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

# Admin routes

@app.route('/api/admin/users')
@admin_required
def admin_list_users():
    """Admin endpoint to list all users"""
    try:
        users = User.query.all()
        return jsonify({
            'success': True,
            'users': [user.to_dict() for user in users],
            'total': len(users)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/admin/user/<int:user_id>')
@admin_required
def admin_get_user(user_id):
    """Get specific user details for admin"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({
                'success': False,
                'error': 'User not found'
            }), 404
        
        return jsonify({
            'success': True,
            'user': {
                'id': user.id,
                'email': user.email,
                'display_name': user.name,
                'subscription_plan': user.subscription_plan,
                'credits': user.credits,
                'created_at': user.created_at.isoformat() if user.created_at else None,
                'last_login': user.last_login.isoformat() if user.last_login else None,
                'is_admin': user.is_admin()
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/admin/user/<int:user_id>', methods=['PUT'])
@require_auth
@admin_required
def admin_update_user(user_id):
    """Update user details for admin"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({
                'success': False,
                'error': 'User not found'
            }), 404
        
        data = request.json
        
        # Update subscription plan
        if 'subscription_plan' in data:
            user.subscription_plan = data['subscription_plan']
            user.subscription_status = 'active' if data['subscription_plan'] != 'trial' else 'trial'
            
            # Update enabled sources based on plan
            from subscription import SUBSCRIPTION_PLANS, ALL_SOURCES, TRIAL_SOURCES
            
            if data['subscription_plan'] == 'ultra':
                user.set_enabled_sources(ALL_SOURCES)
                user.is_nsfw_enabled = True
            elif data['subscription_plan'] in SUBSCRIPTION_PLANS:
                plan = SUBSCRIPTION_PLANS[data['subscription_plan']]
                user.set_enabled_sources(plan['sources'])
                user.is_nsfw_enabled = False
            else:
                user.set_enabled_sources(TRIAL_SOURCES)
                user.is_nsfw_enabled = False
        
        # Update credits
        if 'credits' in data:
            user.credits = int(data['credits'])
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'User updated successfully',
            'user': {
                'id': user.id,
                'subscription_plan': user.subscription_plan,
                'credits': user.credits
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/admin/settings')
@admin_required
def admin_get_settings():
    """Admin endpoint to get all application settings"""
    try:
        settings = AppSetting.query.all()
        settings_dict = {}
        
        for setting in settings:
            settings_dict[setting.key] = {
                'value': setting.get_value(),
                'description': setting.description,
                'type': setting.setting_type,
                'updated_at': setting.updated_at.isoformat() if setting.updated_at else None
            }
        
        return jsonify({
            'success': True,
            'settings': settings_dict
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/admin/settings', methods=['PUT'])
@require_auth
@admin_required
def admin_update_settings():
    """Admin endpoint to update application settings"""
    try:
        data = request.get_json()
        
        for key, value in data.items():
            AppSetting.set_setting(
                key=key,
                value=value,
                user_id=current_user.id
            )
        
        return jsonify({
            'success': True,
            'message': f'Updated {len(data)} settings'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/admin/cleanup')
@admin_required
def admin_cleanup():
    """Admin endpoint to cleanup old jobs and missing files"""
    try:
        cleanup_days = int(request.args.get('days', 30))
        
        # Cleanup old jobs
        cleaned_jobs = db_job_manager.cleanup_old_jobs(cleanup_days)
        
        # Cleanup missing files
        cleaned_assets = db_asset_manager.cleanup_missing_files()
        
        return jsonify({
            'success': True,
            'message': f'Cleaned up {cleaned_jobs} old jobs and {cleaned_assets} missing assets',
            'cleaned_jobs': cleaned_jobs,
            'cleaned_assets': cleaned_assets
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

# AI Assistant Routes

@app.route('/api/ai-assistant', methods=['POST'])
@login_required
def ai_assistant_chat():
    """Enhanced AI assistant with user-based access for MAX subscribers"""
    try:
        from enhanced_ai_service import get_ai_service
        
        data = request.json
        message = data.get('message', '').strip()
        api_key = data.get('api_key', '').strip()  # Optional user API key
        
        if not message:
            return jsonify({
                'success': False,
                'error': 'Message is required'
            })
        
        # Get AI service and process message
        ai_service = get_ai_service()
        response = ai_service.process_message(
            message=message,
            user_id=current_user.id,
            user_api_key=api_key
        )
        
        return jsonify(response)
        
    except ImportError:
        # Fallback to old implementation if enhanced service not available
        try:
            from real_ai_assistant import get_ai_service
            ai_service = get_ai_service()
            response = ai_service.process_message(
                message=message,
                user_id=current_user.id,
                user_api_key=api_key
            )
            return jsonify(response)
        except Exception as e:
            logger.error(f"AI assistant fallback error: {str(e)}")
            return jsonify({
                'success': False,
                'error': 'AI assistant temporarily unavailable',
                'message': "I'm having trouble right now. You can still use basic commands like 'search for cats' or 'show my assets'."
            })
    except Exception as e:
        logger.error(f"AI assistant error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'AI assistant temporarily unavailable',
            'message': "I'm having trouble right now. You can still use basic commands like 'search for cats' or 'show my assets'."
        })

@app.route('/api/ai-assistant/status', methods=['GET'])
@login_required
def ai_assistant_status():
    """Check AI assistant access status for current user"""
    try:
        from enhanced_ai_service import get_ai_service
        
        # Get user's API key from request headers if provided
        user_api_key = request.headers.get('X-OpenAI-API-Key', '').strip()
        
        # Check access status
        ai_service = get_ai_service()
        access = ai_service.check_access(user_api_key)
        
        # Add user subscription info
        access['user'] = {
            'email': current_user.email,
            'subscription_tier': getattr(current_user, 'subscription_tier', 'trial'),
            'is_max_subscriber': getattr(current_user, 'subscription_tier', '') == 'ultra'
        }
        
        return jsonify({
            'success': True,
            **access
        })
        
    except Exception as e:
        logger.error(f"AI status check error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to check AI assistant status'
        })

@app.route('/api/ai-optimize-query', methods=['POST'])
@optional_auth
def ai_optimize_query():
    """AI query optimization endpoint"""
    try:
        from ai_assistant import ai_assistant
        
        data = request.get_json()
        query = data.get('query', '').strip()
        search_type = data.get('search_type', 'comprehensive')
        filters = data.get('filters', {})
        
        if not query:
            return jsonify({
                'success': False,
                'error': 'Query is required'
            }), 400
        
        # Optimize query using AI assistant
        optimized = ai_assistant.optimize_query(query, search_type, filters)
        
        return jsonify({
            'success': True,
            'optimized_query': optimized['query'],
            'optimization_score': optimized['score'],
            'suggestions': optimized['suggestions'],
            'explanation': optimized['explanation']
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/bulletproof-search', methods=['POST'])
@require_auth
@optional_auth
def start_bulletproof_search():
    """Start a new search using the bulletproof download engine"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No JSON data provided'}), 400
            
        query = data.get('query', '').strip()
        sources = data.get('sources', [])
        max_results = int(data.get('maxResults', 25))
        safe_search = data.get('safeSearch', True)
        content_types = data.get('contentTypes', {'images': True, 'videos': True})
        quality_settings = data.get('qualitySettings', {})
        
        print(f"[BULLETPROOF] Starting search for query: {query}")
        print(f"[BULLETPROOF] Sources: {len(sources)}")
        
        if not query:
            return jsonify({'success': False, 'error': 'Query is required'})
        
        if not sources:
            return jsonify({'success': False, 'error': 'At least one source must be selected'})
        
        # Check authentication if required
        if not current_user.is_authenticated:
            allow_guest = AppSetting.get_setting('allow_guest_downloads', False)
            if not allow_guest:
                return jsonify({
                    'success': False,
                    'error': 'Authentication required',
                    'login_required': True
                }), 401
        
        # Check permissions
        if current_user.is_authenticated and not current_user.has_permission('start_jobs'):
            return jsonify({
                'success': False,
                'error': 'Insufficient permissions'
            }), 403
        
        # Create job
        try:
            user_id = current_user.id if current_user.is_authenticated else None
            print(f"[BULLETPROOF] Creating job for user: {user_id}")
            
            job_id = db_job_manager.create_job(
                job_type='bulletproof_multi',
                params={
                    'user_id': user_id,
                    'query': query,
                    'max_content': max_results,
                    'safe_search': safe_search,
                    'enabled_sources': sources,
                    'content_types': content_types,
                    'quality_settings': quality_settings,
                    'engine': 'bulletproof'
                }
            )
            print(f"[BULLETPROOF] Job created: {job_id}")
            
        except Exception as job_error:
            print(f"[BULLETPROOF] Job creation error: {job_error}")
            return jsonify({
                'success': False,
                'error': f'Failed to create job: {str(job_error)}'
            }), 500
        
        # Start bulletproof search in background
        def run_bulletproof_search():
            try:
                print(f"[BULLETPROOF] Starting background search for job {job_id}")
                
                # Initialize bulletproof engine
                bulletproof_engine = get_bulletproof_engine()
                print(f"[BULLETPROOF] Engine initialized")
                
                # Update job status
                db_job_manager.update_job(job_id, status='running')
                db_job_manager.add_progress_update(
                    job_id, 
                    message='Bulletproof engine initialized',
                    progress=10,
                    downloaded=0,
                    images=0,
                    videos=0,
                    current_file='Bulletproof engine initialized'
                )
                
                # Use available downloader
                if REAL_DOWNLOADER_AVAILABLE:
                    try:
                        print(f"[BULLETPROOF] Using comprehensive scraper...")
                        
                        results = comprehensive_multi_source_scrape(
                            query=query,
                            search_type='comprehensive',
                            enabled_sources=sources,
                            max_content_per_source=max(1, max_results // len(sources)) if sources else max_results,
                            output_dir=None,  # Database-only storage
                            safe_search=safe_search,
                            use_queue=False,  # Don't use queue for direct calls
                            job_id=job_id,
                            progress_callback=lambda msg, progress=0, downloaded=0, images=0, videos=0, current_file='': 
                                db_job_manager.add_progress_update(
                                    job_id, 
                                    message=msg,
                                    progress=progress,
                                    downloaded=downloaded,
                                    images=images,
                                    videos=videos,
                                    current_file=current_file
                                )
                        )
                        print(f"[BULLETPROOF] Comprehensive scraper completed")
                        
                    except Exception as comp_error:
                        print(f"[BULLETPROOF] Comprehensive scraper failed: {comp_error}")
                        print(f"[BULLETPROOF] Falling back to simple downloader...")
                        
                        # Import and use simple downloader as fallback
                        from simple_downloader import simple_multi_source_search
                        
                        results = simple_multi_source_search(
                            query=query,
                            sources=sources,
                            max_results_per_source=max(1, max_results // len(sources)) if sources else 5,
                            safe_search=safe_search,
                            progress_callback=lambda msg, progress=0: 
                                db_job_manager.add_progress_update(
                                    job_id, 
                                    message=msg,
                                    progress=progress,
                                    downloaded=0,
                                    images=0,
                                    videos=0,
                                    current_file=msg
                                )
                        )
                        print(f"[BULLETPROOF] Simple downloader fallback completed")
                else:
                    print(f"[BULLETPROOF] Using simple downloader (comprehensive not available)...")
                    
                    # Import and use simple downloader
                    from simple_downloader import simple_multi_source_search
                    
                    results = simple_multi_source_search(
                        query=query,
                        sources=sources,
                        max_results_per_source=max(1, max_results // len(sources)) if sources else 5,
                        safe_search=safe_search,
                        progress_callback=lambda msg, progress=0: 
                            db_job_manager.add_progress_update(
                                job_id, 
                                message=msg,
                                progress=progress,
                                downloaded=0,
                                images=0,
                                videos=0,
                                current_file=msg
                            )
                    )
                    print(f"[BULLETPROOF] Simple downloader completed")
                
                # Process results (common for both downloaders)
                results_count = len(results) if results else 0
                print(f"[BULLETPROOF] Scrape completed with {results_count} results")
                
                # Save results to database
                saved_count = 0
                if results:
                    for result in results:
                        try:
                            asset = db_asset_manager.save_asset(
                                url=result.get('url'),
                                title=result.get('title', 'Untitled'),
                                source=result.get('source', 'unknown'),
                                content_type=result.get('type', 'unknown'),
                                file_path=result.get('local_path'),
                                metadata=result.get('metadata', {}),
                                user_id=user_id,
                                job_id=job_id
                            )
                            if asset:
                                saved_count += 1
                        except Exception as save_error:
                            print(f"[BULLETPROOF] Asset save error: {save_error}")
                
                db_job_manager.update_job(job_id, status='completed')
                
                if saved_count > 0:
                    success_message = f'Download completed! {saved_count} items saved successfully'
                else:
                    success_message = f'Search completed (found {results_count} results, but none could be saved)'
                
                db_job_manager.add_progress_update(
                    job_id, 
                    message=success_message,
                    progress=100,
                    downloaded=saved_count,
                    images=len([r for r in results if r.get('type') == 'image']) if results else 0,
                    videos=len([r for r in results if r.get('type') == 'video']) if results else 0,
                    current_file=f'{saved_count} items saved to database'
                )
                    
            except Exception as scrape_error:
                print(f"[BULLETPROOF] Scrape error: {scrape_error}")
                db_job_manager.update_job(job_id, status='failed', message=str(scrape_error))
                db_job_manager.add_progress_update(
                    job_id, 
                    message=f'Download failed: {str(scrape_error)}',
                    progress=0,
                    downloaded=0,
                    images=0,
                    videos=0,
                    current_file='Error occurred'
                )
                
                print(f"[BULLETPROOF] Job {job_id} completed successfully")
                
            except Exception as e:
                error_msg = f"Bulletproof search error: {str(e)}"
                print(f"[BULLETPROOF] {error_msg}")
                try:
                    db_job_manager.update_job(job_id, status='failed', message=error_msg)
                except:
                    pass  # Avoid nested errors
        
        # Start in background thread
        try:
            thread = threading.Thread(target=run_bulletproof_search)
            thread.daemon = True
            thread.start()
            print(f"[BULLETPROOF] Background thread started for job {job_id}")
        except Exception as thread_error:
            print(f"[BULLETPROOF] Thread creation error: {thread_error}")
            return jsonify({
                'success': False,
                'error': f'Failed to start background job: {str(thread_error)}'
            }), 500
        
        return jsonify({
            'success': True,
            'job_id': job_id,
            'message': 'Bulletproof search started with AI monitoring',
            'engine': 'bulletproof',
            'selected_sources': len(sources)
        })
        
    except Exception as e:
        logger.error(f"Bulletproof search error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/api/job-progress/<job_id>')
@csrf.exempt  # Exempt from CSRF for API usage
@optional_auth
def get_job_progress(job_id):
    """Get detailed progress for a bulletproof search job"""
    try:
        print(f"[DEBUG] Getting job progress for: {job_id}")
        job = db_job_manager.get_job(job_id)
        if not job:
            print(f"[WARNING] Job not found: {job_id}")
            return jsonify({'error': 'Job not found'}), 404
        
        print(f"[DEBUG] Job found: {job.status}, progress: {job.progress}")
        
        # Check access permissions
        if current_user.is_authenticated:
            if job.user_id != current_user.id and not current_user.has_role('admin'):
                return jsonify({'error': 'Access denied'}), 403
        
        # Get bulletproof engine statistics (with fallback)
        try:
            bulletproof_engine = get_bulletproof_engine()
            engine_stats = bulletproof_engine.get_statistics()
        except Exception as e:
            print(f"[WARNING] Failed to get bulletproof engine stats: {e}")
            engine_stats = {
                'total_retries': 0,
                'total_downloads': 0,
                'success_rate': 0,
                'error': 'Engine unavailable'
            }
        
        # Parse metadata safely from available fields
        metadata = {}
        try:
            # Try to get metadata from sources_data field
            if hasattr(job, 'sources_data') and job.sources_data:
                metadata = json.loads(job.sources_data)
            elif hasattr(job, 'live_updates') and job.live_updates:
                live_updates = json.loads(job.live_updates)
                metadata = {'log_entries': live_updates}
        except (json.JSONDecodeError, TypeError, AttributeError) as e:
            print(f"[WARNING] Failed to parse job metadata: {e}")
            metadata = {}
        
        return jsonify({
            'job_id': job_id,
            'status': job.status,
            'overall_progress': job.progress,
            'source_progress': metadata.get('source_progress', 0),
            'current_source': metadata.get('current_source', ''),
            'current_file': job.current_file or '',
            'downloaded_count': job.downloaded,
            'success_count': job.downloaded,
            'retry_count': engine_stats.get('total_retries', 0),
            'error_count': job.failed,
            'engine_stats': engine_stats,
            'log_entries': metadata.get('log_entries', [])
        })
        
    except Exception as e:
        print(f"[ERROR] Progress fetch error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/bulletproof-cancel/<job_id>', methods=['POST'])
@optional_auth
def cancel_bulletproof_job(job_id):
    """Cancel a running bulletproof search job"""
    try:
        job = db_job_manager.get_job(job_id)
        if not job:
            return jsonify({'error': 'Job not found'}), 404
        
        # Check access permissions
        if current_user.is_authenticated:
            if job.user_id != current_user.id and not current_user.has_role('admin'):
                return jsonify({'error': 'Access denied'}), 403
        
        # Cancel the job
        db_job_manager.update_job_progress(job_id, status='cancelled')
        
        return jsonify({
            'success': True,
            'message': 'Job cancelled successfully'
        })
        
    except Exception as e:
        logger.error(f"Job cancellation error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/bulletproof-stats')
@optional_auth
def get_bulletproof_stats():
    """Get bulletproof download engine statistics"""
    try:
        bulletproof_engine = get_bulletproof_engine()
        stats = bulletproof_engine.get_statistics()
        
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        logger.error(f"Stats fetch error: {e}")
        return jsonify({'error': str(e)}), 500

# Legacy routes (maintaining backward compatibility)

@app.route('/test-system')
@optional_auth
def test_system():
    """System test endpoint"""
    try:
        # Test database connection
        from sqlalchemy import text
        db.session.execute(text('SELECT 1'))
        
        # Test sources
        sources = get_content_sources()
        
        # Test authentication status
        auth_status = "authenticated" if current_user.is_authenticated else "guest"
        
        test_results = {
            'database': 'connected',
            'sources_available': len(sources),
            'authentication': auth_status,
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify({
            'success': True,
            'tests': test_results,
            'message': 'All systems operational'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'message': 'System test failed'
        })

@app.route('/test-oauth')
def test_oauth():
    """Test OAuth configuration step by step"""
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>OAuth Configuration Test</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            .step { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
            .check { color: green; font-weight: bold; }
            .error { color: red; font-weight: bold; }
            .test-btn { background: #4285f4; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 10px 0; }
        </style>
    </head>
    <body>
        <h1>[SEARCH] OAuth Configuration Test</h1>
        
        <div class="step">
            <h3>Step 1: Environment Variables</h3>
            <p>Client ID: <span class="check">""" + str(bool(os.environ.get('GOOGLE_CLIENT_ID'))) + """</span></p>
            <p>Client Secret: <span class="check">""" + str(bool(os.environ.get('GOOGLE_CLIENT_SECRET'))) + """</span></p>
            <p>Insecure Transport: <span class="check">""" + str(os.environ.get('OAUTHLIB_INSECURE_TRANSPORT', 'Not Set')) + """</span></p>
        </div>
        
        <div class="step">
            <h3>Step 2: Google Cloud Console Checklist</h3>
            <p>[SUCCESS] OAuth consent screen configured with app name</p>
            <p>[SUCCESS] User support email added</p>
            <p>[SUCCESS] Test user (sop1973@gmail.com) added</p>
            <p>[SUCCESS] People API enabled</p>
            <p>[SUCCESS] Redirect URIs: http://localhost:5000/auth/google/authorized</p>
        </div>
        
        <div class="step">
            <h3>Step 3: Test OAuth Flow</h3>
            <button class="test-btn" onclick="window.location.href='/scraper/auth/login'">[START] Test Google OAuth</button>
            <p><small>If configured correctly, this should redirect to Google and back</small></p>
        </div>
        
        <div class="step">
            <h3>Step 4: Current Status</h3>
            <p>Client ID: """ + os.environ.get('GOOGLE_CLIENT_ID', 'NOT SET')[:20] + """...</p>
            <p>Flask App Running: <span class="check">[SUCCESS]</span></p>
        </div>
        
        <div class="step">
            <h3>[ALERT] If Still Getting 401 Error:</h3>
            <ol>
                <li>Verify OAuth consent screen is PUBLISHED (not in testing)</li>
                <li>Check that redirect URI matches EXACTLY</li>
                <li>Ensure People API is enabled</li>
                <li>Wait 5-10 minutes for Google changes to propagate</li>
            </ol>
        </div>
    </body>
    </html>
    """
    return html

@app.route('/oauth-status')
def oauth_status():
    """Simple OAuth status check"""
    import os
    
    return jsonify({
        'oauth_credentials': {
            'client_id_set': bool(os.environ.get('GOOGLE_CLIENT_ID')),
            'client_secret_set': bool(os.environ.get('GOOGLE_CLIENT_SECRET')),
            'insecure_transport': os.environ.get('OAUTHLIB_INSECURE_TRANSPORT', 'Not Set')
        },
        'server_status': 'running',
        'test_urls': {
            'login': '/scraper/auth/login',
            'main_app': '/scraper/',
            'oauth_test': '/scraper/test-oauth'
        }
    })

@app.route('/debug-oauth')
def debug_oauth():
    """Debug OAuth configuration and status"""
    from auth import google
    import os
    
    debug_info = {
        'environment': {
            'GOOGLE_CLIENT_ID': os.environ.get('GOOGLE_CLIENT_ID', 'NOT SET'),
            'GOOGLE_CLIENT_SECRET': 'SET' if os.environ.get('GOOGLE_CLIENT_SECRET') else 'NOT SET',
            'OAUTHLIB_INSECURE_TRANSPORT': os.environ.get('OAUTHLIB_INSECURE_TRANSPORT', 'NOT SET'),
            'SECRET_KEY': 'SET' if app.config.get('SECRET_KEY') else 'NOT SET'
        },
        'oauth_status': {
            'google_authorized': google.authorized if google else False,
            'has_token': bool(google.token if google else False),
            'google_object_type': str(type(google).__name__) if google else 'None'
        },
        'current_user': {
            'authenticated': current_user.is_authenticated if current_user else False,
            'user_id': current_user.id if current_user and current_user.is_authenticated else None,
            'email': current_user.email if current_user and current_user.is_authenticated else None
        }
    }
    
    if google and google.authorized:
        try:
            resp = google.get("/oauth2/v2/userinfo")
            debug_info['google_api_test'] = {
                'status_code': resp.status_code,
                'success': resp.ok,
                'response': resp.json() if resp.ok else resp.text
            }
        except Exception as e:
            debug_info['google_api_test'] = {
                'error': str(e),
                'error_type': type(e).__name__
            }
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>OAuth Debug Information</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; }}
            .section {{ margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }}
            .success {{ background-color: #d4edda; border-color: #c3e6cb; }}
            .error {{ background-color: #f8d7da; border-color: #f5c6cb; }}
            .warning {{ background-color: #fff3cd; border-color: #ffeaa7; }}
            pre {{ background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }}
            .btn {{ background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }}
        </style>
    </head>
    <body>
        <h1>[SEARCH] OAuth Debug Information</h1>
        
        <div class="section">
            <h3>Environment Variables</h3>
            <pre>{debug_info['environment']}</pre>
        </div>
        
        <div class="section">
            <h3>OAuth Status</h3>
            <pre>{debug_info['oauth_status']}</pre>
        </div>
        
        <div class="section">
            <h3>Current User</h3>
            <pre>{debug_info['current_user']}</pre>
        </div>
        
        {'<div class="section"><h3>Google API Test</h3><pre>' + str(debug_info.get('google_api_test', 'No API test performed')) + '</pre></div>' if 'google_api_test' in debug_info else ''}
        
        <div class="section">
            <h3>Test Actions</h3>
            <button class="btn" onclick="window.location.href='/auth/login'">🔐 Test OAuth Login</button>
            <button class="btn" onclick="window.location.href='/auth/google'">🔗 Direct Google Auth</button>
            <button class="btn" onclick="window.location.href='/'">🏠 Home</button>
        </div>
        
        <div class="section">
            <h3>Full Debug Data</h3>
            <pre>{debug_info}</pre>
        </div>
    </body>
    </html>
    """
    
    return html

@app.route('/dev/reset-credits', methods=['POST'])
@login_required
def dev_reset_credits():
    """Development endpoint to reset user credits for testing"""
    try:
        # Only allow in debug mode
        if not app.debug:
            return jsonify({
                'success': False,
                'error': 'This endpoint is only available in debug mode'
            }), 403
        
        # Get requested credits (default to 50)
        data = request.get_json() or {}
        credits = data.get('credits', 50)
        
        # Reset current user's credits
        current_user.credits = credits
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Credits reset to {credits}',
            'user': current_user.email,
            'credits': current_user.credits
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

# Serve JavaScript fix patch
@app.route('/static/js_fix_patch.js')
def serve_js_fix():
    """Serve the JavaScript fix patch file"""
    try:
        with open('js_fix_patch.js', 'r') as f:
            content = f.read()
        return Response(content, mimetype='application/javascript')
    except FileNotFoundError:
        return Response('// Fix file not found', mimetype='application/javascript', status=404)

# Serve static files
@app.route('/static/<path:filename>')
def serve_static(filename):
    """Serve static files from static directory"""
    return send_from_directory('static', filename)

# Initialize database
def create_tables():
    """Create database tables and initialize with default data"""
    try:
        with app.app_context():
            db.create_all()
            init_db()
            print("[SUCCESS] Database tables created and initialized")
    except Exception as e:
        print(f"[ERROR] Error initializing database: {e}")

@app.route('/api/media/<int:asset_id>/download')
@login_required
def download_media(asset_id):
    """Download a media file (from blob or disk, with access and credit checks)"""
    try:
        from models import MediaBlob, Asset
        asset = Asset.query.get_or_404(asset_id)
        # Check if user can access this asset
        if not check_asset_access(asset, current_user):
            return jsonify({'error': 'Access denied'}), 403
        # Check credits for trial users
        if current_user.subscription_plan == 'trial' and current_user.credits <= 0:
            return jsonify({'error': 'Insufficient credits'}), 403
        # Serve from MediaBlob if available
        media_blob = MediaBlob.query.filter_by(asset_id=asset_id).first()
        if media_blob:
            file_data = media_blob.get_file_data()
            mime_type = media_blob.mime_type
        else:
            if not asset.file_path or not os.path.exists(asset.file_path):
                return jsonify({'error': 'Media file not found'}), 404
            with open(asset.file_path, 'rb') as f:
                file_data = f.read()
            import mimetypes
            mime_type, _ = mimetypes.guess_type(asset.file_path)
            if not mime_type:
                mime_type = 'application/octet-stream'
        # Deduct credit if trial
        if current_user.subscription_plan == 'trial':
            current_user.credits -= 1
            db.session.commit()
        # Watermark for trial/non-subscribed users (images only)
        should_watermark = False
        if current_user.subscription_plan == 'trial' or not current_user.is_subscribed():
            should_watermark = True
        if should_watermark and asset.file_type == 'image':
            file_data = watermark_overlay.apply_watermark_to_image_bytes(file_data)
        # Create response
        response = make_response(file_data)
        response.headers['Content-Type'] = mime_type
        response.headers['Content-Disposition'] = f'attachment; filename="{asset.filename}"'
        response.headers['Cache-Control'] = 'private, max-age=3600'
        response.headers['ETag'] = f'"{asset.id}-{asset.file_size}"'
        if should_watermark:
            response.headers['X-Watermarked'] = 'true'
        return response
    except Exception as e:
        print(f"Download error: {e}")
        return jsonify({'error': 'Download failed'}), 500

@app.route('/api/subscription/status')
@login_required
def subscription_status():
    """Get user subscription status"""
    return jsonify({
        'success': True,
        'is_premium': current_user.is_premium,
        'credits': current_user.credits,
        'daily_downloads': current_user.daily_downloads,
        'max_daily_downloads': 25 if not current_user.is_premium else 999999
    })

@app.route('/api/subscription/upgrade', methods=['POST'])
@login_required
def upgrade_subscription():
    """Upgrade to premium (placeholder)"""
    # This is a placeholder - implement payment processing
    return jsonify({
        'success': False,
        'message': 'Payment processing coming soon!'
    })

@app.route('/api/download-asset', methods=['POST'])
@login_required
def download_asset():
    """Download individual asset from URL"""
    try:
        data = request.json
        url = data.get('url')
        filename = data.get('filename')
        
        if not url or not filename:
            return jsonify({
                'success': False,
                'error': 'URL and filename are required'
            }), 400
        
        # Check if user has credits or subscription
        if not current_user.has_credits():
            return jsonify({
                'success': False,
                'error': 'You have no credits remaining. Please upgrade to continue.',
                'upgrade_required': True
            }), 402
        
        # Use a credit for download
        current_user.use_credit()
        db.session.commit()
        
        # For now, return success (actual download implementation would go here)
        return jsonify({
            'success': True,
            'message': f'Download initiated for {filename}',
            'credits_remaining': current_user.credits
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/stats')
@optional_auth  
def get_stats():
    """Get dashboard statistics"""
    try:
        # Get user-specific stats if authenticated
        if current_user.is_authenticated:
            user_id = current_user.id
            # Get user's asset statistics
            stats = db_asset_manager.get_asset_statistics(user_id=user_id)
            total_downloads = stats['total_assets']
            total_images = stats['total_images']
            total_videos = stats['total_videos']
            total_size = stats['total_size_bytes']
            
            # Get user's job stats
            user_jobs = db_job_manager.get_user_jobs(user_id, limit=100)
            completed_jobs = [j for j in user_jobs if j.get('status') == 'completed']
            success_rate = int((len(completed_jobs) / len(user_jobs)) * 100) if user_jobs else 85
            
        else:
            # Return demo stats for non-authenticated users
            total_downloads = 0
            total_images = 0
            total_videos = 0
            total_size = 0
            success_rate = 85
        
        return jsonify({
            'success': True,
            'stats': {
                'total_downloads': total_downloads,
                'total_images': total_images,
                'total_videos': total_videos,
                'total_size': total_size,
                'success_rate': success_rate
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/current-user')
@optional_auth
def get_current_user():
    """Get current user info for debugging"""
    try:
        if current_user and current_user.is_authenticated:
            return jsonify({
                'authenticated': True,
                'user': {
                    'id': current_user.id,
                    'email': current_user.email,
                    'name': current_user.name,
                    'credits': current_user.credits,
                    'subscription_plan': current_user.subscription_plan,
                    'is_admin': current_user.email.lower() == os.getenv('ADMIN_EMAIL', 'admin@example.com')
                }
            })
        else:
            return jsonify({'authenticated': False})
    except Exception as e:
        return jsonify({'authenticated': False, 'error': str(e)})

@app.route('/admin-test')
def admin_test():
    """Serve admin test page"""
    try:
        with open('admin_test.html', 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return '<h1>Admin test page not found</h1><p>The admin_test.html file is missing.</p>'

if __name__ == '__main__':
    print("[START] === STARTING ENHANCED MEDIA SCRAPER (Database-Driven) ===")
    print("[SERVER] Server: http://localhost:5000")
    print("[MODE] Mode: Enhanced with Database, OAuth, and RBAC")
    print(f"[DATABASE] Database: SQL Server Express - Scraped")
    print("[AUTH] Authentication: Google OAuth Enabled")
    print("[STORAGE] Persistent job tracking and asset management")
    print("==================================================")
    print("[SUCCESS] Database initialized with default roles and settings")
    print("[SUCCESS] Database tables created and initialized")
    
    # Initialize database on startup
    create_tables()
    
    # Start memory management
    try:
        start_memory_management()
        print("[SUCCESS] Memory management started")
    except Exception as e:
        print(f"[WARNING] Memory management failed to start: {e}")
    
    try:
        # Run in debug mode for development
        app.run(debug=True, host='0.0.0.0', port=5000)
    finally:
        # Cleanup on shutdown
        try:
            from memory_manager import stop_memory_management
            stop_memory_management()
            print("[CLEANUP] Memory management stopped")
        except Exception as e:
            print(f"[WARNING] Memory cleanup error: {e}")
