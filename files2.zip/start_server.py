#!/usr/bin/env python3
"""
Production server startup script
Configures and launches the refactored media scraper application
"""
import os
import sys
import logging
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def setup_environment():
    """Setup environment variables"""
    
    # Load environment from .env if exists
    env_file = Path('.env')
    if env_file.exists():
        logger.info("Loading environment from .env")
        with open(env_file) as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    os.environ[key] = value
    
    # Set Flask configuration
    os.environ.setdefault('FLASK_APP', 'app_refactored.py')
    os.environ.setdefault('FLASK_ENV', 'production')
    
    # Database configuration with intelligent fallback
    if not os.environ.get('DATABASE_URL'):
        try:
            import pyodbc  # noqa: F401
            # Default to SQL Server Express if pyodbc present
            os.environ['DATABASE_URL'] = (
                'mssql+pyodbc://localhost\\SQLEXPRESS/Scraped?'
                'driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes'
            )
            logger.info("Using SQL Server Express via pyodbc (default)")
        except Exception:
            # Fall back to SQLite for quick local setup
            instance_dir = Path('instance')
            instance_dir.mkdir(parents=True, exist_ok=True)
            os.environ['DATABASE_URL'] = 'sqlite:///instance/scraper.db'
            logger.warning("pyodbc not available; falling back to SQLite database at instance/scraper.db")
    
    # Create necessary directories
    for directory in ['logs', 'downloads', 'temp', 'src/api', 'instance']:
        Path(directory).mkdir(parents=True, exist_ok=True)

def check_dependencies():
    """Check that all required dependencies are installed"""
    required_modules = [
        'flask',
        'flask_sqlalchemy',
        'flask_login',
        'flask_cors',
        'aiohttp',
        'bs4',  # beautifulsoup4 installs as 'bs4'
        'yt_dlp',
        'requests'
    ]
    
    missing = []
    for module in required_modules:
        try:
            __import__(module.replace('-', '_'))
        except ImportError:
            missing.append(module)
    
    if missing:
        logger.error(f"Missing dependencies: {', '.join(missing)}")
        logger.info("Install with: pip install " + ' '.join(missing))
        sys.exit(1)

def main():
    """Main entry point"""
    logger.info("Starting Media Scraper Server")
    
    # Setup environment
    setup_environment()
    
    # Check dependencies
    check_dependencies()
    
    # Import and create app
    from app_refactored import create_app
    app = create_app()
    
    # Get port from environment or use default
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '127.0.0.1')
    
    logger.info(f"Server starting on {host}:{port}")
    logger.info(f"Access the application at: http://localhost/scraper")
    
    # Run the application
    app.run(
        host=host,
        port=port,
        debug=False,
        threaded=True,
        use_reloader=False
    )

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)
