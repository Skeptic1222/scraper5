param(
    [switch]$VerboseLog
)

$ErrorActionPreference = 'Stop'
Write-Host "Starting Enhanced Media Scraper backend..." -ForegroundColor Cyan

# Ensure required folders
@('logs','downloads','temp','instance') | ForEach-Object { if (-not (Test-Path $_)) { New-Item -ItemType Directory -Force -Path $_ | Out-Null } }

# Choose Python
$venvPython = Join-Path $PSScriptRoot '..\..\..' | Out-Null
$venvPython = Join-Path (Resolve-Path "$PSScriptRoot\..\").Path ".venv\Scripts\python.exe"
if (Test-Path $venvPython) {
    $python = $venvPython
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $python = (Get-Command python).Path
} else {
    throw "Python not found. Please install Python 3.9+ or create .venv first."
}

# Print Python path
Write-Host "Using Python: $python" -ForegroundColor Yellow

# Ensure ODBC driver is installed
$odbc = Get-OdbcDriver | Where-Object { $_.Name -like '*ODBC Driver 1*SQL Server*' }
if (-not $odbc) {
    Write-Warning 'Microsoft ODBC Driver for SQL Server not found. Install ODBC Driver 17 or 18.'
}

# Start server
if ($VerboseLog) { $env:LOG_LEVEL = 'DEBUG' }
& $python start_server.py

