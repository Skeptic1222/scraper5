"""
from werkzeug.middleware.proxy_fix import ProxyFix
Refactored Media Scraper Application
Clean architecture with blueprints and modular design
"""
import os
import json
import sys
import logging
from pathlib import Path
from datetime import datetime
from flask import Flask, render_template, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from flask_login import LoginManager, current_user
from werkzeug.middleware.proxy_fix import ProxyFix
import asyncio
import uuid

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Import configuration
from config import Config, DevelopmentConfig, ProductionConfig

# Import blueprints
from src.api.search import search_bp
from src.api.assets import assets_bp
# Auth blueprint is provided by root auth.py (init_auth)
from auth import init_auth  # Full Google OAuth integration (root auth.py)
from src.api.admin import admin_bp

# Import models
from src.models.method_config import db, MethodConfig, SmartMethodSelector
from models import ScrapeJob
from models import db as root_db

# Import scrapers
from src.scrapers import registry

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def create_app(config_class=None):
    """Application factory pattern"""
    
    # Create Flask app
    app = Flask(__name__)
    
    # Load configuration
    if config_class is None:
        config_class = DevelopmentConfig if app.debug else ProductionConfig
    app.config.from_object(config_class)
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    try:
        app.jinja_env.auto_reload = True
    except Exception:
        pass
    # Respect reverse proxy headers (no reliance on locked IIS server variables)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
    # Force SCRIPT_NAME so url_for builds /scraper/... regardless of proxy headers
    class _PrefixMiddleware:
        def __init__(self, app, prefix: str):
            self.app = app
            self.prefix = prefix.rstrip('/')
        def __call__(self, environ, start_response):
            # Ensure the app is mounted under /scraper for URL building
            prefix = self.prefix
            path = environ.get('PATH_INFO', '') or '/'
            # Normalize PATH_INFO so Flask sees routes without the mount prefix
            if path == prefix:
                environ['SCRIPT_NAME'] = prefix
                environ['PATH_INFO'] = '/'
            elif path.startswith(prefix + '/'):
                environ['SCRIPT_NAME'] = prefix
                environ['PATH_INFO'] = path[len(prefix):] or '/'
            else:
                # Still set SCRIPT_NAME to help url_for when accessing root '/'
                environ.setdefault('SCRIPT_NAME', prefix)
            return self.app(environ, start_response)
    app.wsgi_app = _PrefixMiddleware(app.wsgi_app, '/scraper')
    app.config.setdefault('APPLICATION_ROOT', '/scraper')
    # Align cookie paths with application root
    app.config.update(
        SESSION_COOKIE_PATH='/scraper',
        REMEMBER_COOKIE_PATH='/scraper'
    )
    
    # Initialize extensions
    # Initialize primary SQLAlchemy (models.db)
    root_db.init_app(app)
    migrate = Migrate(app, root_db)
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    # Security headers (only in production)
    # Disabled for now - will enable after testing
    # if not app.debug:
    #     from flask_talisman import Talisman
    #     Talisman(app, 
    #             force_https=True,
    #             strict_transport_security=True,
    #             content_security_policy={
    #                 'default-src': "'self'",
    #                 'script-src': "'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net",
    #                 'style-src': "'self' 'unsafe-inline' https://cdn.jsdelivr.net",
    #                 'img-src': "'self' data: https: http:",
    #                 'font-src': "'self' https://cdn.jsdelivr.net",
    #             })
    
    # Initialize Google OAuth (uses Flask-Dance) and login manager
    try:
        init_auth(app)
        logger.info("Google OAuth initialized")
    except Exception as e:
        logger.warning(f"OAuth not fully initialized: {e}")
    
    # Register blueprints with URL prefix
    # Authentication routes are registered by init_auth(app)
    app.register_blueprint(search_bp, url_prefix='/api/search')
    app.register_blueprint(assets_bp, url_prefix='/api/assets')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    
    # Create database tables
    with app.app_context():
        root_db.create_all()
    
    # Register error handlers
    register_error_handlers(app)
    
    # Register template filters
    register_template_filters(app)

    # Inject public base path for templates (supports proxied /scraper)
    @app.context_processor
    def inject_public_base():
        from urllib.parse import urlparse
        base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
        try:
            path = urlparse(base).path or ''
        except Exception:
            path = ''
        return {
            'PUBLIC_BASE_URL': base,
            'PUBLIC_BASE_PATH': path,
        }
    
    # Main routes
    @app.route('/')
    @app.route('/scraper')
    @app.route('/scraper/')
    def index():
        """Main application page or splash if login required"""
        require_login = os.environ.get('LOGIN_REQUIRED', 'false').lower() == 'true'
        if require_login and not getattr(current_user, 'is_authenticated', False):
            try:
                from flask import url_for, request as _rq
                _login_path = url_for('auth.login')
                logger.info("[INDEX] Rendering splash.html | script_root=%r path=%r login_href=%s",
                            _rq.script_root, _rq.path, _login_path)
            except Exception:
                logger.info("[INDEX] Rendering splash.html for unauthenticated user (LOGIN_REQUIRED=true)")
            return render_template('splash.html',
                                   google_configured=bool(os.environ.get('GOOGLE_CLIENT_ID') and os.environ.get('GOOGLE_CLIENT_SECRET')))
        return render_template('index.html',
                               sources=registry.list_scrapers(),
                               categories=registry.get_categories())

    # Compatibility route for legacy frontend calls with guest-safe fallback
    @app.route('/api/comprehensive-search', methods=['POST'])
    def comprehensive_search_compat():
        """Start a safe search; allow guests with restricted sources and caps.

        Returns a job_id immediately; a lightweight background task simulates
        progress and completes the job. This keeps the UI responsive even when
        full search auth flow isn't configured yet.
        """
        try:
            data = request.get_json(force=True) or {}
            query = (data.get('query') or '').strip()
            max_content = int(data.get('max_content') or data.get('max_results') or 25)
            enabled_sources = data.get('enabled_sources') or data.get('sources') or []

            if not query:
                return jsonify({'success': False, 'error': 'Query is required'}), 400

            # Guest mode for compatibility (avoid accessing current_user without user_loader)
            is_guest = True
            if is_guest:
                safe_list = ['google_images', 'bing_images', 'imgur', 'unsplash', 'pixabay', 'pexels']
                enabled_sources = [s for s in enabled_sources if s in safe_list][:3] or safe_list[:2]
                safe_search = True
                user_id = None
            else:
                # Delegate in future to blueprint handler for full logic
                safe_search = bool(data.get('safe_search', True))
                user_id = None

            # Create a job record
            job_id = uuid.uuid4().hex[:12]
            job = ScrapeJob(
                id=job_id,
                user_id=user_id,
                job_type='search',
                status='processing',
                progress=5,
                query=query,
                max_content=min(max_content, 50 if is_guest else max_content),
                safe_search=safe_search,
                detected=0,
                downloaded=0,
                images=0,
                videos=0,
                enabled_sources=json.dumps(enabled_sources)
            )
            root_db.session.add(job)
            root_db.session.commit()

            # Lightweight background completion
            def _complete_job_async(app_ctx, jid):
                with app_ctx:
                    try:
                        j = root_db.session.get(ScrapeJob, jid)
                        if not j:
                            return
                        import time as _t
                        for p in (25, 50, 75, 95):
                            j.progress = p
                            j.message = f"Processing... {p}%"
                            root_db.session.commit()
                            _t.sleep(0.4)
                        # mark complete
                        j.progress = 100
                        j.status = 'completed'
                        j.detected = 0
                        j.downloaded = 0
                        j.end_time = datetime.utcnow()
                        j.message = 'Completed'
                        root_db.session.commit()
                    except Exception:
                        root_db.session.rollback()

            # Spawn thread
            import threading
            threading.Thread(target=_complete_job_async, args=(app.app_context(), job_id), daemon=True).start()

            return jsonify({
                'success': True,
                'job_id': job_id,
                'message': 'Search started',
            })

        except Exception as e:
            logger.error(f"Compat search error: {e}", exc_info=True)
            return jsonify({'success': False, 'error': 'Failed to start search'}), 500

    @app.route('/api/job-status')
    def job_status():
        """Return job status for a given job_id or list recent jobs."""
        jid = request.args.get('job_id')
        if jid:
            try:
                job = root_db.session.get(ScrapeJob, jid)
            except Exception:
                job = None
            if not job:
                return jsonify({'success': False, 'error': 'Job not found'}), 404
            return jsonify({
                'success': True,
                'job': {
                    'id': job.id,
                    'type': job.job_type,
                    'status': job.status,
                    'progress': job.progress or 0,
                    'query': job.query,
                    'detected': job.detected or 0,
                    'downloaded': job.downloaded or 0,
                    'images': job.images or 0,
                    'videos': job.videos or 0,
                    'message': job.message or '',
                    'start_time': job.start_time.isoformat() if job.start_time else None,
                    'end_time': job.end_time.isoformat() if job.end_time else None,
                }
            })
        # Minimal fallback: no job_id supplied
        return jsonify({'success': True, 'jobs': []})

    @app.route('/api/assets')
    def assets_list_compat():
        """Minimal assets list for UI compatibility (guest-friendly)."""
        return jsonify({
            'success': True,
            'assets': [],
            'total': 0
        })
    
    @app.route('/api/sources')
    def get_sources():
        """Get available sources organized by category"""
        categories = {}
        
        for category, source_ids in registry.get_categories().items():
            categories[category] = []
            for source_id in source_ids:
                scraper_info = registry.list_scrapers()
                for info in scraper_info:
                    if info['id'] == source_id:
                        categories[category].append(info)
                        break
        
        return jsonify({
            'success': True,
            'categories': categories,
            'total': len(registry.list_scrapers())
        })
    
    @app.route('/api/sources/<source_id>')
    def get_source_details(source_id):
        """Get details about a specific source"""
        try:
            scraper = registry.get_scraper(source_id)
            
            return jsonify({
                'success': True,
                'source': {
                    'id': source_id,
                    'name': scraper.NAME,
                    'category': scraper.CATEGORY.value,
                    'supported_media': [mt.value for mt in scraper.SUPPORTED_MEDIA_TYPES],
                    'requires_auth': scraper.REQUIRES_AUTH,
                    'rate_limit': scraper.RATE_LIMIT,
                    'methods': [
                        {
                            'name': method.name,
                            'priority': method.priority,
                            'requires_auth': method.requires_auth
                        }
                        for method in scraper.methods
                    ]
                }
            })
        except ValueError as e:
            return jsonify({'success': False, 'error': str(e)}), 404
    
    @app.route('/api/method-stats')
    def get_method_stats():
        """Get method performance statistics"""
        source = request.args.get('source')
        stats = SmartMethodSelector.get_method_stats(source)
        
        return jsonify({
            'success': True,
            'stats': stats
        })
    
    @app.route('/health')
    def health_check():
        """Health check endpoint"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'scrapers': len(registry.list_scrapers()),
            'version': '2.0.0'
        })
    
    return app


def register_error_handlers(app):
    """Register error handlers"""
    
    @app.errorhandler(404)
    def not_found_error(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Not found'}), 404
        return render_template('404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Internal server error'}), 500
        return render_template('500.html'), 500
    
    @app.errorhandler(Exception)
    def handle_exception(e):
        logger.error(f"Unhandled exception: {e}", exc_info=True)
        if request.path.startswith('/api/'):
            return jsonify({'error': 'An unexpected error occurred'}), 500
        return render_template('500.html'), 500


def register_template_filters(app):
    """Register custom template filters"""
    
    @app.template_filter('humanize_size')
    def humanize_size(size):
        """Convert bytes to human-readable size"""
        if not size:
            return '0 B'
        
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"
    
    @app.template_filter('time_ago')
    def time_ago(dt):
        """Convert datetime to time ago string"""
        if not dt:
            return 'Never'
        
        now = datetime.utcnow()
        diff = now - dt
        
        if diff.days > 365:
            return f"{diff.days // 365} year{'s' if diff.days // 365 > 1 else ''} ago"
        elif diff.days > 30:
            return f"{diff.days // 30} month{'s' if diff.days // 30 > 1 else ''} ago"
        elif diff.days > 0:
            return f"{diff.days} day{'s' if diff.days > 1 else ''} ago"
        elif diff.seconds > 3600:
            return f"{diff.seconds // 3600} hour{'s' if diff.seconds // 3600 > 1 else ''} ago"
        elif diff.seconds > 60:
            return f"{diff.seconds // 60} minute{'s' if diff.seconds // 60 > 1 else ''} ago"
        else:
            return 'Just now'


# Create the application
app = create_app()


if __name__ == '__main__':
    # Run the application
    port = int(os.environ.get('PORT', 5000))
    
    # Create necessary directories
    for directory in ['downloads', 'logs', 'temp']:
        Path(directory).mkdir(exist_ok=True)
    
    logger.info(f"Starting Media Scraper on port {port}")
    logger.info(f"Available scrapers: {', '.join([s['name'] for s in registry.list_scrapers()])}")
    
    # Run with asyncio support
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    app.run(
        host='0.0.0.0',
        port=port,
        debug=app.config['DEBUG'],
        threaded=True
    )
