import os
import logging
from datetime import datetime
from functools import wraps
from flask import Blueprint, redirect, url_for, session, flash, request, jsonify, make_response
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_dance.contrib.google import make_google_blueprint, google
from flask_dance.consumer import oauth_authorized, oauth_error
from flask_dance.consumer.storage import BaseStorage
import json
import requests

logger = logging.getLogger(__name__)

# Custom session storage for OAuth tokens
class SessionStorage(BaseStorage):
    """Store OAuth tokens in Flask session to fix state mismatch"""
    def __init__(self, key="oauth_token"):
        self.key = key
    
    def get(self, blueprint):
        return session.get(self.key)
    
    def set(self, blueprint, token):
        session[self.key] = token
        session.permanent = True
    
    def delete(self, blueprint):
        session.pop(self.key, None)

# In-memory user storage
MEMORY_USERS = {}
MEMORY_ASSETS = []
MEMORY_JOBS = []

class MemoryUser(UserMixin):
    """In-memory user for OAuth when database is unavailable"""
    def __init__(self, google_id, email, name, picture=None):
        self.id = google_id
        self.google_id = google_id
        self.email = email
        self.name = name
        self.picture = picture or f'https://ui-avatars.com/api/?name={name.replace(" ", "+")}'
        self._is_active = True  # Use private attribute
        self.created_at = datetime.utcnow()
        self.last_login = datetime.utcnow()
        
        # Admin check
        is_admin = email.lower() == 'sop1973@gmail.com'
        self.credits = 10000 if is_admin else 50
        self.subscription_plan = 'ultra' if is_admin else 'trial'
        self.subscription_tier = 'ultra' if is_admin else 'trial'
        self.subscription_status = 'active' if is_admin else 'trial'
        self.is_nsfw_enabled = is_admin
        self.signin_bonus_claimed = False
        self.roles = ['admin'] if is_admin else ['user']
        self.display_name = name
        self.is_admin_user = is_admin
        
        # Add missing subscription fields for compatibility
        self.subscription_end_date = None
        self.subscription_id = None
        
        # Add can_use_nsfw method for compatibility
        self.can_use_nsfw = self.is_nsfw_enabled
    
    @property
    def is_active(self):
        """Property for Flask-Login"""
        return self._is_active
    
    def get_id(self):
        return str(self.google_id)
    
    def is_admin(self):
        return self.email.lower() == 'sop1973@gmail.com'
    
    def has_role(self, role):
        if self.is_admin():
            return True
        return role in self.roles
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'name': self.name,
            'display_name': self.name,
            'subscription_plan': self.subscription_plan,
            'credits': self.credits,
            'is_admin': self.is_admin()
        }

# Create blueprints
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

# Initialize login manager
login_manager = LoginManager()

@auth_bp.route('/login')
def login():
    """Redirect to Google OAuth"""
    # Clear any stale OAuth session data
    session.pop('google_oauth_state', None)
    session.pop('_flashes', None)  # Clear any flash messages
    session.pop('google_oauth_token', None)
    session.pop('oauth_token', None)
    
    # Clear Flask-Dance's token storage
    # Note: We can't use google_bp here as it's not defined yet
    # Just clear the session key directly
    session.pop('google_oauth_token', None)
    
    # Force account selection and consent; build absolute URL under PUBLIC_BASE_URL
    public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
    login_path = url_for('google.login', prompt='select_account consent', access_type='online', next=url_for('index'))
    try:
        from flask import request as _rq
        logger.info("[AUTH] /auth/login redirect | script_root=%r path=%r -> %s (public_base=%s)",
                    _rq.script_root, _rq.path, login_path, public_base)
    except Exception:
        pass
    if public_base:
        return redirect(f"{public_base}{login_path}")
    return redirect(login_path)

@auth_bp.route('/logout')
@login_required
def logout():
    """Logout route with proper Google token revocation"""
    # Get current user email before logout
    user_email = current_user.email if current_user.is_authenticated else 'Unknown'
    
    # Try to revoke Google token
    token_revoked = False
    try:
        # Get the OAuth token from Flask-Dance storage
        token = None
        if hasattr(google, 'token') and google.token:
            token = google.token.get('access_token')
        elif 'google_oauth_token' in session:
            token_data = session.get('google_oauth_token')
            if isinstance(token_data, dict):
                token = token_data.get('access_token')
        elif 'oauth_token' in session:
            token_data = session.get('oauth_token')
            if isinstance(token_data, dict):
                token = token_data.get('access_token')
        
        # Revoke the token with Google
        if token:
            revoke_url = 'https://oauth2.googleapis.com/revoke'
            params = {'token': token}
            response = requests.post(revoke_url, params=params, timeout=5)
            if response.status_code == 200:
                token_revoked = True
                logger.info(f"[AUTH] Successfully revoked Google token for: {user_email}")
            else:
                logger.warning(f"[AUTH] Failed to revoke Google token: {response.status_code}")
    except Exception as e:
        logger.error(f"[AUTH] Error revoking Google token: {str(e)}")
    
    # Perform Flask-Login logout
    logout_user()
    
    # Clear Flask-Dance storage
    # Note: We can't use google_bp here as it's not in this scope
    # Just clear the session key directly
    session.pop('google_oauth_token', None)
    
    # Clear ALL session data
    session.pop('google_oauth_state', None)
    session.pop('oauth_token', None)
    session.pop('user_info', None)
    session.pop('_user_id', None)
    session.pop('_fresh', None)
    session.pop('_id', None)
    session.pop('_permanent', None)
    
    # Clear the entire session
    session.clear()
    
    # Force session to be non-permanent
    session.permanent = False
    
    logger.info(f"[AUTH] User logged out: {user_email} (token revoked: {token_revoked})")
    
    if token_revoked:
        flash('You have been logged out completely.', 'success')
    else:
        flash('You have been logged out locally. For complete logout, please sign out of Google.', 'info')
    
    # Create response with session cookie deletion
    public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
    target = f"{public_base}/" if public_base else url_for('index')
    response = make_response(redirect(target))
    response.set_cookie('session', '', expires=0, path='/')
    response.set_cookie('google_oauth_token', '', expires=0, path='/')
    
    # Add cache control headers
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    
    return response

@login_manager.user_loader
def load_user(user_id):
    """Load user from memory"""
    return MEMORY_USERS.get(user_id)

def init_auth(app):
    """Initialize authentication for the Flask app"""
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    # Ensure Flask-Login redirects include the proxied base path (/scraper)
    @login_manager.unauthorized_handler
    def _unauthorized():
        # Build login path via url_for so SCRIPT_NAME/x-forwarded-prefix are honored
        public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
        login_path = url_for('auth.login')
        try:
            from flask import request as _rq
            logger.info("[AUTH] unauthorized -> %s | script_root=%r path=%r public_base=%s",
                        login_path, _rq.script_root, _rq.path, public_base)
        except Exception:
            pass
        return redirect(f"{public_base}{login_path}" if public_base else login_path)
    
    # Configure session for OAuth
    is_https = os.environ.get('PUBLIC_BASE_URL', '').lower().startswith('https://')
    app.config.update(
        SESSION_COOKIE_SECURE=is_https,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE='Lax',
        PERMANENT_SESSION_LIFETIME=3600,
        SESSION_REFRESH_EACH_REQUEST=True  # Refresh session on each request
    )
    
    # Enable insecure transport for development
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
    os.environ['OAUTHLIB_RELAX_TOKEN_SCOPE'] = '1'  # Relax token scope checking
    
    logger.info("[AUTH] Initializing Google OAuth with session storage...")
    
    # Create custom session storage
    storage = SessionStorage('google_oauth_token')
    
    # Derive public base URL for proxied deployments (IIS at /scraper)
    public_base = os.environ.get('PUBLIC_BASE_URL', 'http://localhost/scraper').rstrip('/')
    redirect_override = os.environ.get('GOOGLE_REDIRECT_URL')
    redirect_url = redirect_override or f"{public_base}/login/google/authorized"

    # Create Google OAuth blueprint with session storage and proxied redirect URL
    google_bp = make_google_blueprint(
        client_id=os.environ.get('GOOGLE_CLIENT_ID'),
        client_secret=os.environ.get('GOOGLE_CLIENT_SECRET'),
        scope=["openid", "https://www.googleapis.com/auth/userinfo.email", "https://www.googleapis.com/auth/userinfo.profile"],
        redirect_to=None,  # Don't auto redirect
        redirect_url=redirect_url,
        storage=storage  # Use custom session storage
    )
    
    # Add authorization URL parameters for account selection
    google_bp.auto_refresh_url = None
    google_bp.auto_refresh_kwargs = None
    # Inject prompt parameter into OAuth URLs
    @google_bp.before_app_request
    def inject_google_prompt():
        """Inject prompt parameter for account selection"""
        if request.endpoint == 'google.login':
            # Store the original authorization_url method
            if not hasattr(google_bp.session, '_original_authorization_url'):
                google_bp.session._original_authorization_url = google_bp.session.authorization_url
            
            def custom_authorization_url(url, **kwargs):
                # Always add prompt and access_type
                kwargs['prompt'] = 'select_account consent'
                kwargs['access_type'] = 'online'
                return google_bp.session._original_authorization_url(url, **kwargs)
            
            google_bp.session.authorization_url = custom_authorization_url

    
    # Override the default state storage behavior
    @google_bp.before_app_request
    def fix_oauth_state():
        """Fix OAuth state issues before processing"""
        if request.endpoint == 'google.authorized' and 'state' in request.args:
            # If we have a state parameter but Flask-Dance can't find it in session
            oauth_state = request.args.get('state')
            if oauth_state and not session.get('google_oauth_state'):
                # Store it in the session where Flask-Dance expects it
                session['google_oauth_state'] = oauth_state
                session.permanent = True
                logger.info(f"[AUTH] Restored OAuth state: {oauth_state[:10]}...")
    
    # OAuth error handler
    @oauth_error.connect_via(google_bp)
    def google_error(blueprint, message, response):
        logger.error(f"OAuth error: {message}")
        flash(f"OAuth error: {message}", "error")
        return redirect(url_for("index"))
    
    # OAuth success handler
    @oauth_authorized.connect_via(google_bp)
    def google_logged_in(blueprint, token):
        """Handle successful Google OAuth login"""
        try:
            if not token:
                logger.error("[AUTH] No token received from Google")
                flash("Failed to log in with Google.", category="error")
                return redirect(url_for("index"))
            
            # Get user info from Google
            resp = blueprint.session.get("/oauth2/v2/userinfo")
            if not resp.ok:
                logger.error(f"[AUTH] Failed to get user info: {resp.text}")
                flash("Failed to fetch user information from Google.", category="error")
                return redirect(url_for("index"))
            
            google_info = resp.json()
            google_id = google_info.get('id')
            email = google_info.get('email', 'unknown')
            name = google_info.get('name', email.split('@')[0])
            picture = google_info.get('picture')
            
            logger.info(f"[AUTH] OAuth successful for: {email}")
            
            # Create or update user in memory
            if google_id not in MEMORY_USERS:
                user = MemoryUser(google_id, email, name, picture)
                MEMORY_USERS[google_id] = user
            else:
                user = MEMORY_USERS[google_id]
                user.last_login = datetime.utcnow()
            
            # Log the user in
            login_user(user, remember=True)
            
            # Store in session
            session['user_info'] = user.to_dict()
            session.permanent = True
            
            flash(f"Welcome, {user.name}!", "success")
            # Explicit redirect to proxied base
            public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
            return redirect(public_base or url_for('index'))
            
        except Exception as e:
            logger.error(f"[AUTH] OAuth error: {str(e)}")
            flash("An error occurred during login.", category="error")
            public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
            return redirect(public_base or url_for("index"))
    
    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(google_bp, url_prefix='/login')
    
    return google_bp

# Mock database API endpoints
def init_mock_endpoints(app):
    """Initialize mock API endpoints to bypass database"""
    
    @app.route('/api/assets')
    def api_assets_mock():
        """Return empty assets to avoid database errors"""
        return jsonify({
            'assets': MEMORY_ASSETS,
            'counts': {
                'total': len(MEMORY_ASSETS),
                'all': len(MEMORY_ASSETS),
                'images': len([a for a in MEMORY_ASSETS if a.get('type') == 'image']),
                'videos': len([a for a in MEMORY_ASSETS if a.get('type') == 'video'])
            },
            'statistics': {
                'total_assets': len(MEMORY_ASSETS),
                'total_images': len([a for a in MEMORY_ASSETS if a.get('type') == 'image']),
                'total_videos': len([a for a in MEMORY_ASSETS if a.get('type') == 'video']),
                'total_size_bytes': sum(a.get('size', 0) for a in MEMORY_ASSETS)
            },
            'success': True
        })
    
    @app.route('/api/stats')
    def api_stats_mock():
        """Return mock stats to avoid database errors"""
        return jsonify({
            'stats': {
                'total_assets': len(MEMORY_ASSETS),
                'total_downloads': len(MEMORY_JOBS),
                'active_jobs': len([j for j in MEMORY_JOBS if j.get('status') == 'active']),
                'total_size': sum(a.get('size', 0) for a in MEMORY_ASSETS),
                'user_count': len(MEMORY_USERS),
                'recent_downloads': MEMORY_JOBS[-10:][::-1]
            },
            'success': True
        })
    
    @app.route('/api/jobs')
    def api_jobs_mock():
        """Return empty jobs to avoid database errors"""
        limit = int(request.args.get('limit', 100))
        return jsonify(MEMORY_JOBS[-limit:][::-1])

# Decorators
def admin_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
            login_path = url_for('auth.login')
            return redirect(f"{public_base}{login_path}" if public_base else login_path)
        
        if not current_user.is_admin():
            if request.path.startswith('/api/'):
                return jsonify({'error': 'Admin access required'}), 403
            flash('Access denied', 'error')
            public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
            return redirect(public_base or url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def user_or_admin_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.path.startswith('/api/'):
                return jsonify({'error': 'Authentication required'}), 401
            public_base = os.environ.get('PUBLIC_BASE_URL', '').rstrip('/')
            login_path = url_for('auth.login')
            return redirect(f"{public_base}{login_path}" if public_base else login_path)
        return f(*args, **kwargs)
    return decorated_function

def optional_auth(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        return f(*args, **kwargs)
    return decorated_function

# Additional functions required by app.py
def require_permission(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def require_role(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
            
            if not current_user.has_role(role):
                return jsonify({'error': 'Insufficient permissions'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def check_user_access(user, resource):
    """Check if user has access to resource"""
    return True

def get_current_user_info():
    """Get current user information"""
    if current_user.is_authenticated:
        return current_user.to_dict()
    return None
